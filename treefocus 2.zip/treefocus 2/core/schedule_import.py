"""日程表导入：支持三种来源
- CSV 文件（最可靠，推荐）：列是 day,time,name,duration_minutes
- ICS 日历导出文件（可靠）：标准 iCalendar 格式，大多数日历 App 都能导出
- 图片（尽力而为）：用 OCR 识别图片里的文字，找"时间 + 文字"的行当成一条日程。
  这个需要电脑上装有 Tesseract OCR 引擎，没装会给出清楚的提示而不是崩溃。

三种解析函数都返回 (entries, warnings)：
- entries 是可以直接塞进 main.py 的 timetable 列表里的条目
- warnings 是遇到的问题（跳过了哪一行、识别失败原因等），
  UI 层负责展示给用户，不会因为有 warning 就整体失败
"""

import csv
import os
import re
import uuid
from datetime import datetime

DAY_NAME_MAP = {
    "monday": 0, "mon": 0, "周一": 0, "星期一": 0, "礼拜一": 0,
    "tuesday": 1, "tue": 1, "周二": 1, "星期二": 1, "礼拜二": 1,
    "wednesday": 2, "wed": 2, "周三": 2, "星期三": 2, "礼拜三": 2,
    "thursday": 3, "thu": 3, "周四": 3, "星期四": 3, "礼拜四": 3,
    "friday": 4, "fri": 4, "周五": 4, "星期五": 4, "礼拜五": 4,
    "saturday": 5, "sat": 5, "周六": 5, "星期六": 5, "礼拜六": 5,
    "sunday": 6, "sun": 6, "周日": 6, "星期日": 6, "星期天": 6, "礼拜天": 6,
}

SUPPORTED_EXTENSIONS = {".csv", ".ics", ".png", ".jpg", ".jpeg", ".bmp"}


def _new_id():
    return str(uuid.uuid4())


def _parse_day(text):
    if not text or not text.strip():
        return None  # 空 = 每天
    return DAY_NAME_MAP.get(text.strip().lower())


def _parse_duration_minutes(text, default=60):
    try:
        value = int(float(str(text).strip()))
        return value if value > 0 else default
    except (ValueError, TypeError):
        return default


# ---------- CSV ----------

def parse_csv_file(path):
    """期望列：day, time, name, duration_minutes
    day 留空表示每天；表头可有可无（自动判断第一行是不是表头）。"""
    entries = []
    warnings = []

    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f))
    except OSError as e:
        return [], [f"Couldn't open file: {e}"]

    if not rows:
        return [], ["The file is empty"]

    start_index = 0
    header = [c.strip().lower() for c in rows[0]]
    if "time" in header or "name" in header or "day" in header:
        start_index = 1

    for i, row in enumerate(rows[start_index:], start=start_index + 1):
        if not row or all(not c.strip() for c in row):
            continue
        if len(row) < 3:
            warnings.append(f"Row {i}: not enough columns, skipped")
            continue

        day_text, time_text, name = row[0], row[1].strip(), row[2].strip()
        duration_text = row[3] if len(row) > 3 else "60"

        if not re.match(r"^\d{1,2}:\d{2}$", time_text):
            warnings.append(f"Row {i}: bad time format \"{time_text}\", skipped")
            continue
        if not name:
            warnings.append(f"Row {i}: missing task name, skipped")
            continue

        entries.append({
            "id": _new_id(),
            "day": _parse_day(day_text),
            "date": None,
            "time": time_text,
            "name": name,
            "duration_seconds": _parse_duration_minutes(duration_text) * 60,
        })

    if not entries and not warnings:
        warnings.append("No usable rows found")
    return entries, warnings


# ---------- ICS ----------

def parse_ics_file(path):
    """解析标准 iCalendar (.ics) 文件。带 RRULE:...WEEKLY 的当成每周
    重复（存成星期几）；没有的当成某一天的一次性记录（存具体日期）。"""
    entries = []
    warnings = []

    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except OSError as e:
        return [], [f"Couldn't open file: {e}"]

    blocks = re.findall(r"BEGIN:VEVENT(.*?)END:VEVENT", content, re.DOTALL)
    if not blocks:
        return [], ["No events (VEVENT) found in this .ics file"]

    for block in blocks:
        summary_match = re.search(r"SUMMARY:(.*)", block)
        dtstart_match = re.search(r"DTSTART[^:]*:(\d{8}T\d{6})", block)
        dtend_match = re.search(r"DTEND[^:]*:(\d{8}T\d{6})", block)
        rrule_match = re.search(r"RRULE:(.*)", block)

        name = summary_match.group(1).strip() if summary_match else "Imported event"

        if not dtstart_match:
            warnings.append(f"Skipped \"{name}\": no start time found")
            continue
        try:
            start_dt = datetime.strptime(dtstart_match.group(1).strip(), "%Y%m%dT%H%M%S")
        except ValueError:
            warnings.append(f"Skipped \"{name}\": couldn't parse start time")
            continue

        duration_seconds = 3600
        if dtend_match:
            try:
                end_dt = datetime.strptime(dtend_match.group(1).strip(), "%Y%m%dT%H%M%S")
                duration_seconds = max(60, int((end_dt - start_dt).total_seconds()))
            except ValueError:
                pass

        is_weekly = bool(rrule_match and "WEEKLY" in rrule_match.group(1).upper())

        entry = {
            "id": _new_id(),
            "time": start_dt.strftime("%H:%M"),
            "name": name,
            "duration_seconds": duration_seconds,
        }
        if is_weekly:
            entry["day"] = start_dt.weekday()
            entry["date"] = None
        else:
            entry["day"] = None
            entry["date"] = start_dt.strftime("%Y-%m-%d")

        entries.append(entry)

    if not entries and not warnings:
        warnings.append("No usable events found")
    return entries, warnings


# ---------- 图片 OCR ----------

_TIME_LINE_PATTERN = re.compile(
    r"(\d{1,2})\s*[:：.;lI|]\s*(\d{2})\s*(?:AM|PM|am|pm)?\s*[-–—~]?\s*(.*)"
)
# OCR 有时会把冒号漏掉或读错，兜底再试一次"四位数字挨在一起"的写法（如 0800）
_TIME_LINE_PATTERN_COMPACT = re.compile(
    r"^(\d{1,2})(\d{2})\s*(?:AM|PM|am|pm)?\s*[-–—~]?\s*(.*)"
)


def check_ocr_available():
    """检查这台电脑能不能跑图片识别，返回 (可用与否, 说明文字)"""
    try:
        import pytesseract
        from PIL import Image  # noqa: F401
    except ImportError:
        return False, (
            "Image import needs two Python packages: pytesseract and Pillow.\n"
            "Install them with: pip install pytesseract pillow"
        )

    try:
        pytesseract.get_tesseract_version()
    except Exception:
        return False, (
            "The Tesseract OCR engine isn't installed on this computer "
            "(pytesseract is just a Python wrapper around it).\n"
            "Mac: brew install tesseract\n"
            "Windows: download the installer from "
            "https://github.com/UB-Mannheim/tesseract/wiki\n"
            "Linux: sudo apt install tesseract-ocr"
        )

    return True, ""


def parse_image_file(path):
    """尽力而为地从图片里识别出"时间 + 任务名"这种模式的行。
    识别效果取决于图片清晰度和排版，务必在导入前检查预览。"""
    available, message = check_ocr_available()
    if not available:
        return [], [message]

    import pytesseract
    from PIL import Image

    try:
        image = Image.open(path)
        text = pytesseract.image_to_string(image, lang="chi_sim+eng")
    except Exception:
        try:
            text = pytesseract.image_to_string(image, lang="eng")
        except Exception as e:
            return [], [f"OCR failed: {e}"]

    entries = []
    warnings = []
    for line in text.splitlines():
        line = line.strip()
        line = re.sub(r"^[^\w]+", "", line)  # 去掉行首常见的 OCR 误识别符号，比如 ( ) 【 】
        if not line:
            continue

        match = _TIME_LINE_PATTERN.match(line)
        if not match:
            match = _TIME_LINE_PATTERN_COMPACT.match(line)
        if not match:
            continue

        hh, mm, rest = match.groups()
        try:
            hh, mm = int(hh), int(mm)
        except ValueError:
            continue
        if not (0 <= hh <= 23 and 0 <= mm <= 59):
            continue

        name = rest.strip(" -–—~:：") or "Imported task"
        entries.append({
            "id": _new_id(),
            "day": None,
            "date": None,
            "time": f"{hh:02d}:{mm:02d}",
            "name": name,
            "duration_seconds": 3600,
        })

    if not entries:
        warnings.append(
            "Couldn't find any recognizable \"time + task\" lines in this image. "
            "OCR works best on clear, typed schedules — a CSV file is much more "
            "reliable if this doesn't work well."
        )
    else:
        warnings.append(
            f"Recognized {len(entries)} possible entries from the image — "
            "OCR can misread things, please check the preview carefully before importing."
        )
    return entries, warnings


# ---------- 统一入口 ----------

def import_schedule_file(path):
    """根据文件扩展名自动选用对应的解析方式。"""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        return parse_csv_file(path)
    if ext == ".ics":
        return parse_ics_file(path)
    if ext in (".png", ".jpg", ".jpeg", ".bmp"):
        return parse_image_file(path)
    return [], [f"Unsupported file type: {ext or '(none)'}"]
