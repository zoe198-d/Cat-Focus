# 猫屋商店：完成专注赚"小鱼干"，用来买家具、买猫、换房间风格。
# 商品按大类分组，点进某个大类才能看到具体颜色/款式，
# 每件商品的图片对应 assets/furniture/ 里的文件名（不含扩展名）。

FURNITURE_CATEGORIES = [
    {
        "id": "bowls",
        "category_type": "tool",
        "name": "Bowls",
        "icon": "bowl_metal_blue.png",
        "items": [
            {"id": "bowl_metal_green", "name": "Metal Bowl (Green)", "price": 0, "file": "bowl_metal_green.png"},
            {"id": "bowl_metal_blue", "name": "Metal Bowl (Blue)", "price": 0, "file": "bowl_metal_blue.png"},
            {"id": "bowl_metal_purple", "name": "Metal Bowl (Purple)", "price": 0, "file": "bowl_metal_purple.png"},
            {"id": "bowl_metal_red", "name": "Metal Bowl (Red)", "price": 0, "file": "bowl_metal_red.png"},
            {"id": "bowl_food_green", "name": "Food Bowl (Green)", "price": 3, "file": "bowl_food_green.png"},
            {"id": "bowl_food_maroon", "name": "Food Bowl (Maroon)", "price": 3, "file": "bowl_food_maroon.png"},
            {"id": "bowl_food_skyblue", "name": "Food Bowl (Sky Blue)", "price": 3, "file": "bowl_food_skyblue.png"},
        ],
    },
    {
        "id": "food",
        "category_type": "tool",
        "name": "Cat Food",
        "icon": "food.png",
        "items": [
            {"id": "food", "name": "Cat Food Bag", "price": 2, "file": "food.png", "feeds_pet": True},
        ],
    },
    {
        "id": "toys",
        "category_type": "tool",
        "name": "Toys",
        "icon": "mouse_toy.png",
        "items": [
            {"id": "cat_teaser", "name": "Cat Teaser", "price": 4, "file": "cat_teaser.png"},
            {"id": "mouse_toy", "name": "Toy Mouse", "price": 4, "file": "mouse_toy.png"},
            {"id": "fish_treat_blue", "name": "Fish Treat (Blue)", "price": 2, "file": "fish_treat_blue.png"},
            {"id": "fish_treat_orange", "name": "Fish Treat (Orange)", "price": 2, "file": "fish_treat_orange.png"},
            {"id": "fish_treat_gray", "name": "Fish Treat (Gray)", "price": 2, "file": "fish_treat_gray.png"},
            {"id": "fish_treat_yellow", "name": "Fish Treat (Yellow-Green)", "price": 2, "file": "fish_treat_yellow.png"},
            {"id": "fish_toy_blue", "name": "Fish Plushie (Blue)", "price": 5, "file": "fish_toy_blue.png"},
            {"id": "fish_toy_rainbow", "name": "Fish Plushie (Rainbow)", "price": 5, "file": "fish_toy_rainbow.png"},
            {"id": "fish_toy_red", "name": "Fish Plushie (Red)", "price": 5, "file": "fish_toy_red.png"},
            {"id": "fish_toy_teal", "name": "Fish Plushie (Teal)", "price": 5, "file": "fish_toy_teal.png"},
        ],
    },
    {
        "id": "beds",
        "category_type": "furniture",
        "name": "Cat Beds",
        "icon": "bed_blue.png",
        "items": [
            {"id": "bed_blue", "name": "Square Bed (Blue)", "price": 6, "file": "bed_blue.png"},
            {"id": "bed_pink", "name": "Square Bed (Pink)", "price": 6, "file": "bed_pink.png"},
            {"id": "bed_green", "name": "Square Bed (Green)", "price": 6, "file": "bed_green.png"},
            {"id": "bed_brown", "name": "Square Bed (Brown)", "price": 6, "file": "bed_brown.png"},
            {"id": "bed_red", "name": "Square Bed (Red)", "price": 6, "file": "bed_red.png"},
            {"id": "bed_purple", "name": "Square Bed (Purple)", "price": 6, "file": "bed_purple.png"},
            {"id": "bed_round_blue", "name": "Round Bed (Blue)", "price": 7, "file": "bed_round_blue.png"},
            {"id": "bed_round_gray", "name": "Round Bed (Gray)", "price": 7, "file": "bed_round_gray.png"},
            {"id": "bed_round_green", "name": "Round Bed (Green)", "price": 7, "file": "bed_round_green.png"},
            {"id": "bed_round_maroon", "name": "Round Bed (Maroon)", "price": 7, "file": "bed_round_maroon.png"},
            {"id": "bed_round_purple", "name": "Round Bed (Purple)", "price": 7, "file": "bed_round_purple.png"},
            {"id": "bed_round_teal", "name": "Round Bed (Teal)", "price": 7, "file": "bed_round_teal.png"},
            {"id": "cat_house_blue", "name": "Cat House Bed (Blue)", "price": 10, "file": "cat_house_blue.png"},
            {"id": "cat_house_green", "name": "Cat House Bed (Green)", "price": 10, "file": "cat_house_green.png"},
            {"id": "cat_house_purple", "name": "Cat House Bed (Purple)", "price": 10, "file": "cat_house_purple.png"},
            {"id": "cat_house_brown", "name": "Cat House Bed (Brown)", "price": 10, "file": "cat_house_brown.png"},
        ],
    },
    {
        "id": "towers",
        "category_type": "furniture",
        "name": "Scratchers / Trees",
        "icon": "scratch_tower_blue.png",
        "items": [
            {"id": "post_tan", "name": "Scratch Post (Wood)", "price": 6, "file": "post_tan.png"},
            {"id": "post_olive", "name": "Scratch Post (Olive)", "price": 6, "file": "post_olive.png"},
            {"id": "post_blue", "name": "Scratch Post (Blue)", "price": 6, "file": "post_blue.png"},
            {"id": "scratch_tower_green", "name": "Scratch Tower (Green)", "price": 9, "file": "scratch_tower_green.png"},
            {"id": "scratch_tower_blue", "name": "Scratch Tower (Blue)", "price": 9, "file": "scratch_tower_blue.png"},
            {"id": "scratch_tower_purple", "name": "Scratch Tower (Purple)", "price": 9, "file": "scratch_tower_purple.png"},
            {"id": "scratch_tower_red", "name": "Scratch Tower (Red)", "price": 9, "file": "scratch_tower_red.png"},
            {"id": "tree_tiered_purple", "name": "Tiered Cat Tree (Purple)", "price": 11, "file": "tree_tiered_purple.png"},
            {"id": "playground", "name": "Playground", "price": 10, "file": "playground.png"},
            {"id": "playground_light", "name": "Playground (Light)", "price": 10, "file": "playground_light.png"},
        ],
    },
    {
        "id": "furniture",
        "category_type": "furniture",
        "name": "Furniture",
        "icon": "table_blue.png",
        "items": [
            {"id": "shelf_white", "name": "Shelf", "price": 8, "file": "shelf_white.png"},
            {"id": "table_tan", "name": "Round Table (Wood)", "price": 6, "file": "table_tan.png"},
            {"id": "table_gray", "name": "Round Table (Gray)", "price": 6, "file": "table_gray.png"},
            {"id": "table_maroon", "name": "Round Table (Maroon)", "price": 6, "file": "table_maroon.png"},
            {"id": "table_blue", "name": "Round Table (Blue)", "price": 6, "file": "table_blue.png"},
            {"id": "table_purple", "name": "Round Table (Purple)", "price": 6, "file": "table_purple.png"},
            {"id": "stool_cream", "name": "Stool (Cream)", "price": 5, "file": "stool_cream.png"},
            {"id": "stool_mint", "name": "Stool (Mint)", "price": 5, "file": "stool_mint.png"},
            {"id": "stool_pink", "name": "Stool (Pink)", "price": 5, "file": "stool_pink.png"},
            {"id": "stool_lightblue", "name": "Stool (Light Blue)", "price": 5, "file": "stool_lightblue.png"},
            {"id": "stool_white", "name": "Stool (White)", "price": 5, "file": "stool_white.png"},
            {"id": "stool_tan", "name": "Stool (Wood)", "price": 5, "file": "stool_tan.png"},
        ],
    },
    {
        "id": "windows",
        "category_type": "furniture",
        "name": "Windows / Curtains",
        "icon": "window_cream.png",
        "items": [
            {"id": "window_cream", "name": "Window (Cream)", "price": 5, "file": "window_cream.png"},
            {"id": "window_brown_small", "name": "Window (Brown, Small)", "price": 5, "file": "window_brown_small.png"},
            {"id": "window_gray", "name": "Window (Gray)", "price": 5, "file": "window_gray.png"},
            {"id": "window_brown_large", "name": "Window (Brown, Large)", "price": 7, "file": "window_brown_large.png"},
            {"id": "window_blind_purple", "name": "Blind Window (Purple)", "price": 7, "file": "window_blind_purple.png"},
            {"id": "window_blind_dark", "name": "Blind Window (Dark)", "price": 7, "file": "window_blind_dark.png"},
            {"id": "window_blind_teal", "name": "Blind Window (Teal)", "price": 7, "file": "window_blind_teal.png"},
            {"id": "window_blind_gray", "name": "Blind Window (Gray)", "price": 7, "file": "window_blind_gray.png"},
            {"id": "vent_panel", "name": "Vent Panel", "price": 4, "file": "vent_panel.png"},
        ],
    },
    {
        "id": "plants",
        "category_type": "furniture",
        "name": "Plants / Wall Art",
        "icon": "plant_tall.png",
        "items": [
            {"id": "plant_pink", "name": "Small Plant (Pink Pot)", "price": 3, "file": "plant_pink.png"},
            {"id": "plant_cream", "name": "Small Plant (Cream Pot)", "price": 3, "file": "plant_cream.png"},
            {"id": "plant_pale", "name": "Small Plant (Pale Pot)", "price": 3, "file": "plant_pale.png"},
            {"id": "plant_medium", "name": "Medium Plant", "price": 4, "file": "plant_medium.png"},
            {"id": "plant_tall", "name": "Tall Plant", "price": 5, "file": "plant_tall.png"},
            {"id": "plant_picture", "name": "Plant Wall Art", "price": 4, "file": "plant_picture.png"},
        ],
    },
    {
        "id": "fountains",
        "category_type": "furniture",
        "name": "Water Fountains",
        "icon": "fountain_white.png",
        "items": [
            {"id": "fountain_white", "name": "Water Fountain (White)", "price": 9, "file": "fountain_white.png"},
            {"id": "fountain_tan", "name": "Water Fountain (Wood)", "price": 9, "file": "fountain_tan.png"},
            {"id": "fountain_pedestal_gray", "name": "Tabletop Fountain (Gray)", "price": 8, "file": "fountain_pedestal_gray.png"},
            {"id": "fountain_pedestal_tan", "name": "Tabletop Fountain (Wood)", "price": 8, "file": "fountain_pedestal_tan.png"},
        ],
    },
]

# 房间风格（换整个房间背景的颜色/款式），跟家具是分开的一套逻辑：
# 买了/选过的风格会一直解锁，之后随时可以免费切换回去，不用重复付费
ROOM_STYLES = [
    {"id": f"room{i}", "name": f"Room Style {i}", "price": 0 if i == 1 else 5, "file": f"room{i}.png"}
    for i in range(1, 16)
]

CAT_PRICE = 8  # 买一只新猫需要的小鱼干数量

# 买到的猫按这个顺序循环换毛色，不会每只都长得一样
CAT_COLORS = ["orange", "cream", "white", "gray"]

STARTER_FURNITURE_ID = "bowl_metal_blue"  # 初始就送一件家具，房子不至于空荡荡的
DEFAULT_ROOM_ID = "room1"

# 房间画布的默认尺寸（放置物品的 x/y 坐标都是相对这个尺寸算的）
ROOM_CANVAS_WIDTH = 360
ROOM_CANVAS_HEIGHT = 270


def get_cat_color(color_index: int) -> str:
    """第几只猫（从 0 开始数，按购买顺序）对应哪个毛色文件名"""
    return CAT_COLORS[color_index % len(CAT_COLORS)]


def get_category_by_id(category_id: str) -> dict:
    for cat in FURNITURE_CATEGORIES:
        if cat["id"] == category_id:
            return cat
    return None


def get_furniture_by_id(item_id: str) -> dict:
    """在所有分类里找某件商品的信息（不管在哪个分类下）"""
    for cat in FURNITURE_CATEGORIES:
        for item in cat["items"]:
            if item["id"] == item_id:
                return item
    return None


def get_room_by_id(room_id: str) -> dict:
    for room in ROOM_STYLES:
        if room["id"] == room_id:
            return room
    return None


def _new_id() -> str:
    import uuid
    return str(uuid.uuid4())


def ensure_house_fields(progress: dict) -> None:
    """确保 progress.json 里有这些字段（兼容旧存档 / 首次运行）。

    每一件买到的家具/每一只猫都是一个独立"实例"（哪怕是同一款家具买了
    两次，也是两个不同的实例，可以分别摆在房间不同位置）：

    - owned_furniture_instances: [{"id":.., "item_id":.., "color_index":..}]
      买到但还没摆出来的会保留在这个列表里、但不出现在 placed_furniture 里，
      也就是"库存"
    - placed_furniture: [{"instance_id":.., "x":.., "y":..}]
      已经摆在房间里的家具，记录摆放坐标
    - owned_cats: [{"id":.., "color_index":..}]
    - placed_cats: [{"cat_id":.., "x":.., "y":..}]
    """
    progress.setdefault("fish", 0)
    progress.setdefault("room_style", DEFAULT_ROOM_ID)
    progress.setdefault("owned_rooms", [DEFAULT_ROOM_ID])

    progress.setdefault("owned_furniture_instances", [])
    progress.setdefault("placed_furniture", [])
    progress.setdefault("owned_cats", [])
    progress.setdefault("placed_cats", [])
    # 桌面上那只真实的桌宠在猫屋房间画布里的位置（不是"买"来的猫，
    # 是同一只桌宠的镜像，所以单独存位置，不用 owned_cats/placed_cats）
    progress.setdefault("pet_room_pos", {
        "x": ROOM_CANVAS_WIDTH // 2 - 20,
        "y": ROOM_CANVAS_HEIGHT // 2 - 20,
    })

    # 桌宠的血条(饱食度) + 爱心值：喂食恢复饱食度，喂满了再喂就攒爱心值
    progress.setdefault("pet_hunger", 100)
    progress.setdefault("pet_love", 0)

    # 自定义背景相册：把截图/图片拖到桌宠身上会存进这里（免费），
    # 但要花小鱼干才能真的换成房间背景（见 CUSTOM_BACKGROUND_PRICE）
    progress.setdefault("custom_backgrounds", [])       # [{"id":.., "filename":..}]
    progress.setdefault("owned_custom_backgrounds", [])  # 已经花钱解锁过的 id 列表

    if not progress["owned_furniture_instances"]:
        # 初始送一件家具，房子不至于空荡荡的
        progress["owned_furniture_instances"].append(
            {"id": _new_id(), "item_id": STARTER_FURNITURE_ID}
        )


def earn_fish(progress: dict, amount: int = 1) -> None:
    ensure_house_fields(progress)
    progress["fish"] += amount


def buy_furniture(progress: dict, item_id: str) -> bool:
    """尝试购买一件家具（进入库存，还没摆进房间），
    成功返回 True，小鱼干不够返回 False"""
    ensure_house_fields(progress)
    item = get_furniture_by_id(item_id)
    if item is None or progress["fish"] < item["price"]:
        return False
    progress["fish"] -= item["price"]
    progress["owned_furniture_instances"].append({"id": _new_id(), "item_id": item_id})
    return True


def buy_cat(progress: dict) -> bool:
    """买一只新猫（进入库存，还没摆进房间）"""
    ensure_house_fields(progress)
    if progress["fish"] < CAT_PRICE:
        return False
    progress["fish"] -= CAT_PRICE
    color_index = len(progress["owned_cats"])
    progress["owned_cats"].append({"id": _new_id(), "color_index": color_index})
    return True


def select_or_buy_room(progress: dict, room_id: str) -> bool:
    """切换到某个房间风格。已经解锁过的风格随时免费切换；
    没解锁过的需要花小鱼干解锁（解锁后就一直是你的了）。"""
    ensure_house_fields(progress)
    room = get_room_by_id(room_id)
    if room is None:
        return False

    if room_id in progress["owned_rooms"]:
        progress["room_style"] = room_id
        return True

    if progress["fish"] < room["price"]:
        return False

    progress["fish"] -= room["price"]
    progress["owned_rooms"].append(room_id)
    progress["room_style"] = room_id
    return True


# ---------- 自定义背景相册（把图片拖到桌宠身上会存进这里）----------

CUSTOM_BACKGROUND_PRICE = 50  # 比内置房间风格贵不少，毕竟是你自己的照片
CUSTOM_BACKGROUND_ID_PREFIX = "custom_"


def is_custom_background_id(bg_id: str) -> bool:
    return bool(bg_id) and bg_id.startswith(CUSTOM_BACKGROUND_ID_PREFIX)


def get_custom_backgrounds(progress: dict) -> list:
    ensure_house_fields(progress)
    return progress["custom_backgrounds"]


def get_custom_background_by_id(progress: dict, bg_id: str) -> dict:
    for bg in progress.get("custom_backgrounds", []):
        if bg["id"] == bg_id:
            return bg
    return None


def set_custom_background_crop(progress: dict, bg_id: str, crop: dict) -> None:
    """记住这张自定义背景要用原图的哪一块（归一化坐标 0~1：x,y,w,h）。"""
    bg = get_custom_background_by_id(progress, bg_id)
    if bg is not None:
        bg["crop"] = crop


def delete_custom_background(progress: dict, bg_id: str) -> str:
    """从相册里删掉一张自定义背景，返回它的文件名（调用方负责删磁盘上的
    实际文件）。如果这张正好是当前用的房间背景，会自动切回默认房间。"""
    ensure_house_fields(progress)
    bg = get_custom_background_by_id(progress, bg_id)
    if bg is None:
        return None

    progress["custom_backgrounds"] = [
        b for b in progress["custom_backgrounds"] if b["id"] != bg_id
    ]
    progress["owned_custom_backgrounds"] = [
        i for i in progress["owned_custom_backgrounds"] if i != bg_id
    ]
    if progress.get("room_style") == bg_id:
        progress["room_style"] = DEFAULT_ROOM_ID
    return bg["filename"]


def register_custom_background(progress: dict, filename: str) -> str:
    """把一张已经存到本地的图片文件登记进相册（免费），
    返回这条相册记录的 id（不会自动应用成房间背景，还得花钱解锁）。"""
    ensure_house_fields(progress)
    bg_id = f"{CUSTOM_BACKGROUND_ID_PREFIX}{_new_id()}"
    progress["custom_backgrounds"].append({"id": bg_id, "filename": filename})
    return bg_id


def is_custom_background_owned(progress: dict, bg_id: str) -> bool:
    ensure_house_fields(progress)
    return bg_id in progress["owned_custom_backgrounds"]


def select_or_buy_custom_background(progress: dict, bg_id: str) -> bool:
    """跟 select_or_buy_room 是同一个道理，只是价格固定是
    CUSTOM_BACKGROUND_PRICE，而且图片存在 data/ 目录而不是 assets/ 里。"""
    ensure_house_fields(progress)
    if get_custom_background_by_id(progress, bg_id) is None:
        return False

    if bg_id in progress["owned_custom_backgrounds"]:
        progress["room_style"] = bg_id
        return True

    if progress["fish"] < CUSTOM_BACKGROUND_PRICE:
        return False

    progress["fish"] -= CUSTOM_BACKGROUND_PRICE
    progress["owned_custom_backgrounds"].append(bg_id)
    progress["room_style"] = bg_id
    return True


# ---------- 摆放 / 收回 ----------

def get_inventory_furniture(progress: dict, category_type: str = None) -> list:
    """还没摆进房间的家具实例列表，可以按 category_type ("furniture"/"tool") 筛选"""
    ensure_house_fields(progress)
    placed_ids = {p["instance_id"] for p in progress["placed_furniture"]}
    result = []
    for inst in progress["owned_furniture_instances"]:
        if inst["id"] in placed_ids:
            continue
        item = get_furniture_by_id(inst["item_id"])
        if item is None:
            continue
        if category_type is not None:
            cat = None
            for c in FURNITURE_CATEGORIES:
                if any(i["id"] == inst["item_id"] for i in c["items"]):
                    cat = c
                    break
            if cat is None or cat.get("category_type") != category_type:
                continue
        result.append(inst)
    return result


def get_inventory_cats(progress: dict) -> list:
    """还没摆进房间的猫列表"""
    ensure_house_fields(progress)
    placed_ids = {p["cat_id"] for p in progress["placed_cats"]}
    return [c for c in progress["owned_cats"] if c["id"] not in placed_ids]


def place_furniture(progress: dict, instance_id: str, x: int, y: int) -> bool:
    ensure_house_fields(progress)
    if not any(i["id"] == instance_id for i in progress["owned_furniture_instances"]):
        return False
    progress["placed_furniture"] = [
        p for p in progress["placed_furniture"] if p["instance_id"] != instance_id
    ]
    progress["placed_furniture"].append({"instance_id": instance_id, "x": x, "y": y})
    return True


def move_placed_furniture(progress: dict, instance_id: str, x: int, y: int) -> None:
    for p in progress.get("placed_furniture", []):
        if p["instance_id"] == instance_id:
            p["x"], p["y"] = x, y
            return


def unplace_furniture(progress: dict, instance_id: str) -> None:
    progress["placed_furniture"] = [
        p for p in progress.get("placed_furniture", []) if p["instance_id"] != instance_id
    ]


def place_cat(progress: dict, cat_id: str, x: int, y: int) -> bool:
    ensure_house_fields(progress)
    if not any(c["id"] == cat_id for c in progress["owned_cats"]):
        return False
    progress["placed_cats"] = [p for p in progress["placed_cats"] if p["cat_id"] != cat_id]
    progress["placed_cats"].append({"cat_id": cat_id, "x": x, "y": y})
    return True


def move_placed_cat(progress: dict, cat_id: str, x: int, y: int) -> None:
    for p in progress.get("placed_cats", []):
        if p["cat_id"] == cat_id:
            p["x"], p["y"] = x, y
            return


def unplace_cat(progress: dict, cat_id: str) -> None:
    progress["placed_cats"] = [
        p for p in progress.get("placed_cats", []) if p["cat_id"] != cat_id
    ]


def move_pet_in_room(progress: dict, x: int, y: int) -> None:
    """记住桌面桌宠在猫屋房间画布里被拖到的位置"""
    ensure_house_fields(progress)
    progress["pet_room_pos"] = {"x": x, "y": y}


# ---------- 血条(饱食度) / 爱心值 ----------

HUNGER_PER_FEED = 30
HUNGER_MAX = 100
DECAY_PER_TICK = 1  # 每次自然衰减掉多少饱食度

# 每种毛色对应的血条颜色（跟桌宠身上的毛色呼应）
PET_COLOR_RGB = {
    "orange": (240, 152, 80),
    "gray": (150, 150, 150),
    "white": (210, 205, 195),
    "cream": (222, 196, 160),
}


def get_pet_bar_color(color: str):
    return PET_COLOR_RGB.get(color, PET_COLOR_RGB["orange"])


def feed_pet(progress: dict) -> str:
    """喂一次猫粮。饱食度没满就先补饱食度；已经是满的就转成攒爱心值。
    返回 "hunger" 或 "love"，方便 UI 显示不同的提示。"""
    ensure_house_fields(progress)
    if progress["pet_hunger"] >= HUNGER_MAX:
        progress["pet_love"] += 1
        return "love"
    progress["pet_hunger"] = min(HUNGER_MAX, progress["pet_hunger"] + HUNGER_PER_FEED)
    return "hunger"


def decay_pet_hunger(progress: dict, amount: int = DECAY_PER_TICK) -> None:
    ensure_house_fields(progress)
    progress["pet_hunger"] = max(0, progress["pet_hunger"] - amount)
