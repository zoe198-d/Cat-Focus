import sys
import json
import os
from datetime import datetime, timedelta

from PySide6.QtWidgets import QApplication, QMainWindow, QTabWidget, QSplashScreen
from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QCursor, QPixmap, QImage

from pages.setup_page import SetupPage
from pages.cat_house_page import CatHousePage
from pages.timetable_page import TimetablePage
from widgets.desktop_pet import DesktopPet
from widgets.onboarding import run_onboarding
from widgets.theme import get_theme_qss
from core.cat_house_data import earn_fish, decay_pet_hunger, register_custom_background

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
PROGRESS_FILE = os.path.join(DATA_DIR, "progress.json")
TIMETABLE_FILE = os.path.join(DATA_DIR, "timetable.json")
ONBOARDING_FILE = os.path.join(DATA_DIR, "onboarding.json")
CUSTOM_BG_DIR = os.path.join(DATA_DIR, "custom_backgrounds")

CUSTOM_BG_MAX_DIMENSION = 3500  # 只是防止内存爆炸的宽松上限，不是"压缩"——
                                  # 具体用图片的哪一块当背景，由用户在猫屋里手动选

SCHEDULER_INTERVAL_MS = 5 * 1000  # 每5秒检查一次日程表，响应更快
HUNGER_DECAY_INTERVAL_MS = 10 * 60 * 1000  # 每10分钟饱食度自然掉一点，得记得喂猫
HUNGER_DECAY_AMOUNT = 2

_mac_nap_activity_token = None


def _prevent_macos_app_nap():
    """在 Mac 上阻止系统把这个程序"打盹"（App Nap），
    否则切到后台太久，倒计时/日程表定时检查会被系统暂停。
    没装 pyobjc 就直接跳过，不影响其他功能。"""
    global _mac_nap_activity_token
    if sys.platform != "darwin":
        return
    try:
        from Foundation import NSProcessInfo, NSActivityUserInitiated, NSActivityLatencyCritical
        info = NSProcessInfo.processInfo()
        _mac_nap_activity_token = info.beginActivityWithOptions_reason_(
            NSActivityUserInitiated | NSActivityLatencyCritical,
            "Cat Focus needs to keep timers and the schedule running in the background"
        )
    except ImportError:
        pass


def load_progress():
    if not os.path.exists(PROGRESS_FILE):
        return {}
    with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_progress(data):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_timetable():
    if not os.path.exists(TIMETABLE_FILE):
        return []
    with open(TIMETABLE_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_timetable(entries):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(TIMETABLE_FILE, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)


def has_seen_onboarding():
    if not os.path.exists(ONBOARDING_FILE):
        return False
    try:
        with open(ONBOARDING_FILE, "r", encoding="utf-8") as f:
            return json.load(f).get("done", False)
    except (json.JSONDecodeError, OSError):
        return False


def mark_onboarding_seen():
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(ONBOARDING_FILE, "w", encoding="utf-8") as f:
        json.dump({"done": True}, f)


def _entry_interval_today(entry, today_date, current_weekday):
    """算出这条日程"今天"对应的 [开始时间, 结束时间)。
    不适用于今天（比如指定了别的星期几，或者是别的日期的一次性记录）就返回 None。"""
    date_str = entry.get("date")
    if date_str:
        if date_str != today_date.strftime("%Y-%m-%d"):
            return None
    else:
        day = entry.get("day")
        if day is not None and day != current_weekday:
            return None

    time_str = entry.get("time", "")
    try:
        hh, mm = map(int, time_str.split(":"))
    except (ValueError, AttributeError):
        return None

    start_dt = datetime(
        today_date.year, today_date.month, today_date.day, hh, mm
    )
    duration = entry.get("duration_seconds", 0)
    end_dt = start_dt + timedelta(seconds=duration)
    return start_dt, end_dt


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Cat Focus 🐱")
        self.resize(480, 700)

        self.progress = load_progress()
        self.timetable = load_timetable()

        # 记录"今天已经取消过"的日程 id，防止取消后立刻被同一时段重新触发
        self._cancelled_today = {}
        # 当前是被日程表哪一条驱动的（None = 不是日程表触发的，比如手动开始/空闲）
        self._active_schedule_entry_id = None

        # 桌宠常驻显示：程序一打开就出现，默认是"睡觉"状态
        self.pet = DesktopPet(
            on_finished=self.on_task_finished,
            color=self.progress.get("cat_color", "orange"),
            on_image_dropped=self.on_image_dropped_on_pet,
        )
        self.pet.start()

        # 顶部标签：计时 / 种树 / 日程表，随时可以点击切换
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        self.setup_page = SetupPage(self.on_manual_start, self.on_manual_cancel)
        self.cat_house_page = CatHousePage(
            self.progress, save_progress, pet=self.pet, custom_bg_dir=CUSTOM_BG_DIR
        )
        self.timetable_page = TimetablePage(self.timetable, save_timetable)

        self.tabs.addTab(self.setup_page, "⏱ Timer")
        self.tabs.addTab(self.cat_house_page, "🏠 Cat House")
        self.tabs.addTab(self.timetable_page, "📅 Schedule")

        self.scheduler_timer = QTimer(self)
        self.scheduler_timer.timeout.connect(self._check_schedule)
        self.scheduler_timer.start(SCHEDULER_INTERVAL_MS)

        self.hunger_timer = QTimer(self)
        self.hunger_timer.timeout.connect(self._decay_hunger)
        self.hunger_timer.start(HUNGER_DECAY_INTERVAL_MS)

        # 程序一打开就立刻检查一次：如果重开时正好处在某个安排的时间段里
        # （比如之前在计时，程序被关掉又重新打开），马上恢复倒计时
        self._check_schedule()

    def apply_cat_color(self, color):
        """首次引导选完猫的毛色后调用：记住选择并让桌宠立刻换上这个颜色。"""
        self.progress["cat_color"] = color
        save_progress(self.progress)
        self.pet.set_color(color)

    def on_image_dropped_on_pet(self, image=None, path=None, raw_bytes=None):
        """有人把图片/截图拖到桌宠身上了：存进本地相册文件夹，
        登记进"自定义背景"相册（免费），猫屋那边下次刷新就能看到。
        真要用它当房间背景还得花小鱼干解锁，解锁后会让你自己选图片的
        哪一块当背景（不会自动帮你裁/压缩）。

        返回 True/False，方便桌宠那边知道要显示"存好了"还是"失败了"。
        """
        os.makedirs(CUSTOM_BG_DIR, exist_ok=True)

        if image is not None and not isinstance(image, QImage):
            image = None
        if image is not None and image.isNull():
            image = None

        if image is None and path:
            image = QImage(path)
            if image.isNull():
                image = None

        if image is None and (raw_bytes or path):
            # QImage 解不出来（常见于某些 App 用 TIFF 之类的格式拖图），
            # 用 Pillow 兜底再试一次，它支持的格式更广
            try:
                from PIL import Image as PILImage
                import io as _io

                if raw_bytes:
                    pil_image = PILImage.open(_io.BytesIO(raw_bytes))
                else:
                    pil_image = PILImage.open(path)
                pil_image = pil_image.convert("RGBA")
                data = pil_image.tobytes("raw", "RGBA")
                qimage = QImage(data, pil_image.width, pil_image.height, QImage.Format_RGBA8888)
                image = qimage.copy()  # 深拷贝一份，脱离上面局部变量 data 的生命周期
            except Exception:
                image = None

        if image is None or image.isNull():
            return False

        # 只做一个很宽松的兜底上限，避免有人拖进来一张几十兆的原始照片
        # 占用过多内存/磁盘——这不是"自动裁剪"，实际要显示哪一块由用户
        # 在猫屋里解锁时自己选（见 cat_house_page.py 的裁剪弹窗）
        if max(image.width(), image.height()) > CUSTOM_BG_MAX_DIMENSION:
            image = image.scaled(
                CUSTOM_BG_MAX_DIMENSION, CUSTOM_BG_MAX_DIMENSION,
                Qt.KeepAspectRatio, Qt.SmoothTransformation
            )

        filename = f"custom_{datetime.now().strftime('%Y%m%d%H%M%S%f')}.png"
        full_path = os.path.join(CUSTOM_BG_DIR, filename)
        if not image.save(full_path, "PNG"):
            return False

        register_custom_background(self.progress, filename)
        save_progress(self.progress)
        if hasattr(self, "cat_house_page"):
            self.cat_house_page.refresh()
        return True

    def _decay_hunger(self):
        decay_pet_hunger(self.progress, HUNGER_DECAY_AMOUNT)
        save_progress(self.progress)
        if hasattr(self, "cat_house_page"):
            self.cat_house_page.refresh()

    def on_manual_start(self, project_name, duration_seconds):
        now = datetime.now()
        entry = {
            "id": f"manual-{now.strftime('%Y%m%d%H%M%S')}",
            "day": None,
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M"),
            "name": project_name,
            "duration_seconds": duration_seconds,
        }
        self.timetable.append(entry)
        save_timetable(self.timetable)
        self.timetable_page.refresh()

        # 立刻标记成"日程表已经知道这个任务在跑了"，这样调度器下次检查
        # 不会把它当成新任务重新触发，取消的时候也能正确记录
        self._active_schedule_entry_id = entry["id"]
        self.pet.start_task(project_name, duration_seconds)

    def on_manual_cancel(self):
        """用户主动点了"取消"：桌宠回到睡觉状态，不算完成，不浇水。
        如果这次任务是日程表自动触发的，记一下"今天取消过"，
        避免几秒后被同一时间段重新触发。"""
        if self._active_schedule_entry_id is not None:
            self._cancelled_today[self._active_schedule_entry_id] = datetime.now().strftime("%Y-%m-%d")
        self._active_schedule_entry_id = None
        self.pet.go_idle()

    def on_task_finished(self, project_name):
        # 完成一次专注（不管是手动开始的还是日程表自动触发的）：赚一条小鱼干
        earn_fish(self.progress, 1)
        save_progress(self.progress)

        self.cat_house_page.refresh()
        self.setup_page.set_running(False)
        self.setup_page.set_status(f"Done: {project_name} 🐟 You earned a fish treat — check the Cat House tab!")
        self._active_schedule_entry_id = None

    def _check_schedule(self):
        now = datetime.now()
        today_date = now.date()
        today_str = today_date.strftime("%Y-%m-%d")
        current_weekday = now.weekday()

        active_entry = None
        active_interval = None

        for entry in self.timetable:
            interval = _entry_interval_today(entry, today_date, current_weekday)
            if interval is None:
                continue
            start_dt, end_dt = interval
            if not (start_dt <= now < end_dt):
                continue

            entry_id = entry.get("id")
            if self._cancelled_today.get(entry_id) == today_str:
                continue  # 今天已经被手动取消过，不再自动重新触发

            active_entry = entry
            active_interval = interval
            break  # 简化处理：假设日程之间不重叠，命中第一条就够了

        if active_entry is not None:
            entry_id = active_entry.get("id")
            if entry_id != self._active_schedule_entry_id:
                _, end_dt = active_interval
                remaining = max(1, int((end_dt - now).total_seconds()))
                self.pet.start_task(active_entry.get("name", "Focus"), remaining)
                self._active_schedule_entry_id = entry_id
                self.setup_page.set_running(True)
                self.setup_page.set_status(f"📅 Auto-started from schedule: {active_entry.get('name', 'Focus')}")
        else:
            if self._active_schedule_entry_id is not None:
                # 之前由日程表驱动的这段时间已经过去了，交回控制权
                # （桌宠自己的倒计时到点时也会触发 on_task_finished，这里只是兜底）
                self._active_schedule_entry_id = None


UI_ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "ui")


def _apply_magnifier_cursor(app):
    """把整个程序的鼠标指针换成像素风放大镜（来自猫咪UI素材）。
    素材找不到就跳过，用回系统默认指针。"""
    cursor_path = os.path.join(UI_ASSETS_DIR, "cursor_magnify.png")
    if not os.path.exists(cursor_path):
        return
    pixmap = QPixmap(cursor_path)
    if pixmap.isNull():
        return
    # 原图很小(17x13)，放大3倍才看得清，热点放在放大镜镜片中心
    scaled = pixmap.scaled(pixmap.width() * 3, pixmap.height() * 3)
    app.setOverrideCursor(QCursor(scaled, scaled.width() // 3, scaled.height() // 3))


def _show_paw_splash(app):
    """启动时用猫爪四连帧当一个小小的加载动画，给程序初始化这个真实存在
    （虽然很短）的等待过程配个可爱的过场，而不是硬造一个假的等待。
    返回 (splash, timer)，调用方需要保留这两个引用，不然会被垃圾回收。"""
    frames = []
    for i in range(1, 5):
        path = os.path.join(UI_ASSETS_DIR, f"paw_{i}.png")
        if not os.path.exists(path):
            continue
        pixmap = QPixmap(path)
        if pixmap.isNull():
            continue
        frames.append(pixmap.scaled(
            pixmap.width() * 3, pixmap.height() * 3,
            Qt.KeepAspectRatio, Qt.FastTransformation
        ))
    if not frames:
        return None, None

    splash = QSplashScreen(frames[0])
    splash.show()
    app.processEvents()

    state = {"index": 0}

    def _advance_frame():
        state["index"] = (state["index"] + 1) % len(frames)
        splash.setPixmap(frames[state["index"]])

    timer = QTimer()
    timer.timeout.connect(_advance_frame)
    timer.start(150)
    return splash, timer


def main():
    _prevent_macos_app_nap()
    app = QApplication(sys.argv)
    app.setStyleSheet(get_theme_qss())
    _apply_magnifier_cursor(app)
    splash, splash_timer = _show_paw_splash(app)

    window = MainWindow()
    window.show()

    if splash is not None:
        # 至少展示够一小段时间，让爪印动画能看清楚循环一轮，
        # 不会因为初始化太快而一闪而过
        def _close_splash():
            splash.finish(window)
            splash_timer.stop()

        QTimer.singleShot(900, _close_splash)

    if not has_seen_onboarding():
        # 用 singleShot 让窗口先完整显示出来，再弹引导，体验更顺滑
        def _start_onboarding():
            run_onboarding(window)
            mark_onboarding_seen()

        QTimer.singleShot(1100, _start_onboarding)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
