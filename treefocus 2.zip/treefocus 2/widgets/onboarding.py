import os

from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap

APP_NAME = "Cat Focus"

ASSETS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "cat"
)
COLOR_ICON_DIR = os.path.join(ASSETS_DIR, "colors")

# 首次引导里可以选的猫毛色，要跟 widgets/desktop_pet.py 的 AVAILABLE_COLORS 对应
CAT_COLOR_CHOICES = [
    {"id": "orange", "name": "Orange Cat", "icon": "orange.png"},
    {"id": "gray", "name": "Gray Cat", "icon": "gray.png"},
    {"id": "white", "name": "White Cat", "icon": "white.png"},
]

# 每个标签页对应的介绍文案，顺序要和 main.py 里 addTab 的顺序一致
TAB_INTROS = [
    {
        "emoji": "⏱",
        "title": "Timer",
        "text": (
            "Write down your project name and duration here to start "
            "a focus session.\nA cat will hang out on your screen "
            "the whole time!"
        ),
    },
    {
        "emoji": "🏠",
        "title": "Cat House",
        "text": (
            "This is your cat house. Completing focus sessions earns "
            "fish,\nwhich you can spend on furniture and new cats."
        ),
    },
    {
        "emoji": "📅",
        "title": "Schedule",
        "text": (
            "You can also schedule focus sessions ahead of time.\n"
            "When the time comes, the cat pops up and starts the countdown!"
        ),
    },
]


def _make_dialog(parent, title_text, body_text, button_text, mascot_color="orange"):
    dialog = QDialog(parent)
    dialog.setWindowTitle(APP_NAME)
    dialog.setFixedWidth(340)
    dialog.setWindowFlags(dialog.windowFlags() & ~Qt.WindowContextHelpButtonHint)
    dialog.setStyleSheet("QDialog { background-color: #FFF8EF; }")

    layout = QVBoxLayout()
    layout.setContentsMargins(30, 22, 30, 22)
    layout.setSpacing(12)

    mascot_path = os.path.join(COLOR_ICON_DIR, f"{mascot_color}.png")
    mascot_pixmap = QPixmap(mascot_path)
    if not mascot_pixmap.isNull():
        mascot_label = QLabel()
        mascot_label.setPixmap(
            mascot_pixmap.scaled(64, 64, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        )
        mascot_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(mascot_label)

    title_label = QLabel(title_text)
    title_label.setStyleSheet("font-size: 20px; font-weight: bold; color: #6B4A36;")
    title_label.setAlignment(Qt.AlignCenter)
    title_label.setWordWrap(True)
    layout.addWidget(title_label)

    body_label = QLabel(body_text)
    body_label.setStyleSheet("font-size: 14px; color: #7A6355;")
    body_label.setAlignment(Qt.AlignCenter)
    body_label.setWordWrap(True)
    layout.addWidget(body_label)

    button = QPushButton(button_text)
    button.setStyleSheet(
        "padding: 8px; font-size: 14px; background-color: #E8A662; "
        "color: white; border-radius: 10px; font-weight: bold;"
    )
    button.clicked.connect(dialog.accept)
    layout.addWidget(button)

    dialog.setLayout(layout)
    return dialog


def _choose_cat_dialog(parent):
    """选择第一只猫的毛色。返回选中的颜色 id（用户关了窗口没选的话，
    默认给橘猫，不会卡住整个引导流程）。"""
    dialog = QDialog(parent)
    dialog.setWindowTitle(APP_NAME)
    dialog.setWindowFlags(dialog.windowFlags() & ~Qt.WindowContextHelpButtonHint)

    selected = {"color": "orange"}  # 默认值

    layout = QVBoxLayout()
    layout.setContentsMargins(30, 26, 30, 22)
    layout.setSpacing(14)

    title_label = QLabel("Choose Your First Cat 🐱")
    title_label.setStyleSheet("font-size: 20px; font-weight: bold;")
    title_label.setAlignment(Qt.AlignCenter)
    layout.addWidget(title_label)

    hint_label = QLabel("You can always buy more cats later in the Cat House")
    hint_label.setStyleSheet("font-size: 12px; color: #888;")
    hint_label.setAlignment(Qt.AlignCenter)
    layout.addWidget(hint_label)

    choices_row = QHBoxLayout()
    for choice in CAT_COLOR_CHOICES:
        card = QVBoxLayout()

        icon_label = QLabel()
        pixmap = QPixmap(os.path.join(COLOR_ICON_DIR, choice["icon"]))
        if not pixmap.isNull():
            icon_label.setPixmap(
                pixmap.scaled(56, 56, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            )
        icon_label.setAlignment(Qt.AlignCenter)
        card.addWidget(icon_label)

        name_label = QLabel(choice["name"])
        name_label.setAlignment(Qt.AlignCenter)
        card.addWidget(name_label)

        pick_button = QPushButton("Pick")
        pick_button.setStyleSheet(
            "padding: 6px; background-color: #4CAF50; color: white; border-radius: 6px;"
        )

        def _make_handler(color_id):
            def _handler():
                selected["color"] = color_id
                dialog.accept()
            return _handler

        pick_button.clicked.connect(_make_handler(choice["id"]))
        card.addWidget(pick_button)

        choices_row.addLayout(card)

    layout.addLayout(choices_row)
    dialog.setLayout(layout)
    dialog.exec()

    return selected["color"]


def run_onboarding(main_window):
    """只在第一次打开程序时调用。按顺序：欢迎 -> 依次介绍每个标签页
    （介绍的同时会自动切换到对应标签，让用户直接看到那个页面）->
    选择第一只猫的毛色 -> 结束提示。
    每一步都是模态弹窗，用户点按钮才会进入下一步。"""

    welcome = _make_dialog(
        main_window,
        f"Welcome to {APP_NAME} 🐱",
        "Let's take a few seconds to check out the three tabs~",
        "Start",
    )
    welcome.exec()

    for index, intro in enumerate(TAB_INTROS):
        main_window.tabs.setCurrentIndex(index)
        is_last = index == len(TAB_INTROS) - 1
        button_text = "Next" if not is_last else "Got it"
        step_dialog = _make_dialog(
            main_window,
            f"{intro['emoji']} {intro['title']}",
            intro["text"],
            button_text,
        )
        step_dialog.exec()

    # 回到"计时"标签，让用户在这个页面上选猫（正好能马上看到桌宠换色）
    main_window.tabs.setCurrentIndex(0)
    chosen_color = _choose_cat_dialog(main_window)
    main_window.apply_cat_color(chosen_color)

    # 收尾提示（用刚选的毛色当作这个提示框的小可爱头像，正好呼应一下）
    outro = _make_dialog(
        main_window,
        "🎉 That's the tour!",
        "Now go explore on your own~",
        "Get Started",
        mascot_color=chosen_color,
    )
    outro.exec()
