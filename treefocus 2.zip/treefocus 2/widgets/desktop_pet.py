import os
import random
import sys

from PySide6.QtWidgets import QWidget, QApplication
from PySide6.QtCore import Qt, QTimer, QPoint
from PySide6.QtGui import QPainter, QColor, QFont, QPen, QPixmap, QImage

FRAME_SIZE = 32  # 素材是 32x32 一帧的精灵条
DISPLAY_SCALE = 3  # 放大 3 倍，32px 的猫在屏幕上太小看不清

ASSETS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "cat"
)
ANIMATIONS_DIR = os.path.join(ASSETS_DIR, "animations")

AVAILABLE_COLORS = ["orange", "gray", "white"]
DEFAULT_COLOR = "orange"

# 桌面桌宠现在统一只用这三个动作（不管哪个毛色），随机轮换
FIXED_ANIMATION_POOL = ["box1", "waiting", "idle"]
ANIMATION_SWITCH_MS = 60 * 1000  # 每 1 分钟随机切一次


def _load_frames(path):
    """把一条横向精灵图切成一帧一帧的 QPixmap 列表。
    素材找不到或损坏就返回空列表，调用方会自动退回到 emoji 兜底显示。"""
    if not os.path.exists(path):
        return []
    sheet = QPixmap(path)
    if sheet.isNull() or sheet.height() < FRAME_SIZE:
        return []
    frame_count = max(1, sheet.width() // FRAME_SIZE)
    frames = []
    for i in range(frame_count):
        frame = sheet.copy(i * FRAME_SIZE, 0, FRAME_SIZE, FRAME_SIZE)
        scaled = frame.scaled(
            FRAME_SIZE * DISPLAY_SCALE, FRAME_SIZE * DISPLAY_SCALE,
            Qt.KeepAspectRatio, Qt.FastTransformation
        )
        frames.append(scaled)
    return frames


def _load_all_animations(color):
    """加载某个毛色文件夹下固定的三个动作（box1/waiting/idle），
    返回 {名字: [QPixmap, ...]}。缺哪个文件就跳过哪个，不会整体崩溃。"""
    color_dir = os.path.join(ANIMATIONS_DIR, color)
    animations = {}
    if not os.path.isdir(color_dir):
        return animations
    for name in FIXED_ANIMATION_POOL:
        frames = _load_frames(os.path.join(color_dir, f"{name}.png"))
        if frames:
            animations[name] = frames
    return animations


IMAGE_DROP_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp"}


def _disable_hides_on_deactivate(widget):
    """mac 专用：Qt.Tool 窗口默认在 App 切到后台时会自动隐藏，
    这里显式关掉这个行为，让宠物在你切到别的软件后依然留在桌面上。"""
    if sys.platform != "darwin":
        return
    try:
        import objc
        view = objc.objc_object(c_void_p=int(widget.winId()))
        window = view.window()
        if window is not None:
            window.setHidesOnDeactivate_(False)
    except Exception:
        pass


class DesktopPet(QWidget):
    """常驻桌面的宠物：

    - 三个毛色（橘/灰/白）统一只用 box1 / waiting / idle 这三个动作，
      每 1 分钟随机切换一次
    - "working" 状态下额外显示怀里的倒计时球；"idle" 状态下只有猫，没有球
    - 状态切换由外部驱动（手动开始专注 / 日程表到点自动触发）
    - 可以直接用鼠标按住拖走
    """

    BALL_SIZE = 42
    DONE_DISPLAY_SECONDS = 5
    ANIMATION_FRAME_MS = 150  # 每 150 毫秒切一帧动画

    def __init__(self, on_finished=None, color=DEFAULT_COLOR, on_image_dropped=None):
        super().__init__()
        self.on_finished = on_finished  # 回调签名：on_finished(project_name)
        self.on_image_dropped = on_image_dropped  # 回调签名：on_image_dropped(image=None, path=None)
        self.color = color if color in AVAILABLE_COLORS else DEFAULT_COLOR

        self.mode = "idle"  # "idle" 或 "working"
        self.is_done = False
        self.done_ticks = 0
        self.project_name = ""
        self.remaining_seconds = 0
        self._finished_called = False
        self._feedback_text = ""  # 拖图片进来后短暂显示的提示文字

        self.animations = {}
        self.current_animation_key = None
        self.frames = []
        self._frame_index = 0
        self._load_color(self.color)

        frame_w = FRAME_SIZE * DISPLAY_SCALE
        frame_h = FRAME_SIZE * DISPLAY_SCALE
        self.WIDTH = frame_w + 20
        self.HEIGHT = frame_h + 20

        # 拖拽相关状态
        self._dragging = False
        self._drag_start_mouse = QPoint()
        self._drag_start_window = QPoint()

        # 无边框、不抢焦点、不在任务栏显示
        self.setWindowFlags(
            Qt.FramelessWindowHint
            | Qt.Tool
            | Qt.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.setFocusPolicy(Qt.NoFocus)
        self.setAcceptDrops(True)
        self.resize(self.WIDTH, self.HEIGHT)

        screen = QApplication.primaryScreen().geometry()
        start_x = screen.right() - self.WIDTH - 40
        start_y = screen.bottom() - self.HEIGHT - 40
        self.move(start_x, start_y)

        self.tick_timer = QTimer(self)
        self.tick_timer.timeout.connect(self._tick)

        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self._advance_frame)

        self.switch_timer = QTimer(self)
        self.switch_timer.timeout.connect(self._switch_random_animation)

    def _load_color(self, color):
        self.animations = _load_all_animations(color)
        default_key = "idle" if "idle" in self.animations else next(iter(self.animations), None)
        self.current_animation_key = default_key
        self.frames = self.animations.get(default_key, [])
        self._frame_index = 0

    def start(self):
        """显示宠物（空闲/睡觉状态）。整个程序运行期间只调用一次。"""
        self.show()
        _disable_hides_on_deactivate(self)
        self.tick_timer.start(1000)
        self.animation_timer.start(self.ANIMATION_FRAME_MS)
        self.switch_timer.start(ANIMATION_SWITCH_MS)
        self.update()

    def set_color(self, color):
        """切换猫的毛色（重新加载那个颜色的整套动画）。"""
        if color not in AVAILABLE_COLORS or color == self.color:
            return
        self.color = color
        self._load_color(color)
        self.update()

    def _set_animation(self, key):
        self.current_animation_key = key
        self.frames = self.animations.get(key, [])
        self._frame_index = 0
        self.setAcceptDrops(True)  # 保险起见每次都重新声明一下，防止意外被重置
        self.update()

    def _switch_random_animation(self):
        """每分钟从 box1 / waiting / idle 这三个里随机切换一个。"""
        if self._dragging:
            return
        choices = [k for k in self.animations if k != self.current_animation_key]
        if not choices:
            return
        self._set_animation(random.choice(choices))

    def start_task(self, project_name, duration_seconds):
        """开始一次专注任务：切换到"工作"状态并开始倒计时（单位：秒）。"""
        self.project_name = project_name
        self.remaining_seconds = duration_seconds
        self.mode = "working"
        self.is_done = False
        self.done_ticks = 0
        self._finished_called = False
        self._frame_index = 0
        self.update()

    def go_idle(self):
        """手动切回空闲/睡觉状态（比如中途想取消当前任务）。"""
        self.mode = "idle"
        self.is_done = False
        self.project_name = ""
        self._frame_index = 0
        self.update()

    # ---------- 拖拽 ----------
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = True
            self._drag_start_mouse = event.globalPosition().toPoint()
            self._drag_start_window = self.pos()

    def mouseMoveEvent(self, event):
        if self._dragging:
            delta = event.globalPosition().toPoint() - self._drag_start_mouse
            self.move(self._drag_start_window + delta)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = False

    # ---------- 拖图片进来 ----------
    def dragEnterEvent(self, event):
        mime = event.mimeData()
        if mime.hasImage() or mime.hasUrls():
            event.acceptProposedAction()
            return
        event.ignore()

    def dropEvent(self, event):
        mime = event.mimeData()
        result = False

        if mime.hasImage():
            image = QImage(mime.imageData())
            if not image.isNull() and self.on_image_dropped:
                result = self.on_image_dropped(image=image)

            if not result:
                # QImage 解不出这个格式（比如某些 App 用 TIFF 拖图），
                # 把每种它提供的图片格式的原始字节都交给上层，用 Pillow 兜底试着解
                for fmt in mime.formats():
                    lowered = fmt.lower()
                    if "image" not in lowered and "tiff" not in lowered and "png" not in lowered and "jpeg" not in lowered:
                        continue
                    raw_bytes = bytes(mime.data(fmt))
                    if raw_bytes and self.on_image_dropped:
                        result = self.on_image_dropped(raw_bytes=raw_bytes)
                        if result:
                            break

        if not result and mime.hasUrls():
            for url in mime.urls():
                path = url.toLocalFile()
                if path and os.path.splitext(path)[1].lower() in IMAGE_DROP_EXTENSIONS:
                    if self.on_image_dropped:
                        result = self.on_image_dropped(path=path)
                    break

        if result:
            event.acceptProposedAction()
            self._show_feedback("📸 Saved to album!")
        else:
            event.ignore()
            self._show_feedback("❌ Couldn't read that image")

    def _show_feedback(self, text):
        self._feedback_text = text
        self.update()
        QTimer.singleShot(2000, self._clear_feedback)

    def _clear_feedback(self):
        self._feedback_text = ""
        self.update()

    # ---------- 动画帧 ----------
    def _advance_frame(self):
        if not self.frames:
            return
        self._frame_index = (self._frame_index + 1) % len(self.frames)
        self.update()

    def _current_frame(self):
        if not self.frames:
            return None
        index = self._frame_index % len(self.frames)
        return self.frames[index]

    # ---------- 每秒 tick ----------
    def _tick(self):
        if self._dragging or self.mode != "working":
            return

        if self.is_done:
            self.done_ticks += 1
            if self.done_ticks >= self.DONE_DISPLAY_SECONDS:
                self.go_idle()
            self.update()
            return

        self.remaining_seconds -= 1
        if self.remaining_seconds <= 0:
            self.remaining_seconds = 0
            self.is_done = True
            if not self._finished_called:
                self._finished_called = True
                if self.on_finished:
                    self.on_finished(self.project_name)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, False)  # 保留像素风格

        is_working = self.mode == "working"
        frame = self._current_frame()

        if frame is not None:
            x = (self.WIDTH - frame.width()) // 2
            y = (self.HEIGHT - frame.height()) // 2
            painter.drawPixmap(x, y, frame)
        else:
            # 素材没找到时的兜底显示
            pet_font = QFont()
            pet_font.setPointSize(36)
            painter.setFont(pet_font)
            painter.drawText(0, 0, self.WIDTH, self.HEIGHT, Qt.AlignCenter, "🐱")

        if not is_working:
            if self._feedback_text:
                self._draw_feedback(painter)
            return

        # 怀里的球：显示倒计时 / DONE
        ball_x = self.WIDTH - self.BALL_SIZE - 2
        ball_y = self.HEIGHT - self.BALL_SIZE - 2

        ball_color = QColor(255, 152, 0, 235) if not self.is_done else QColor(33, 150, 243, 235)
        painter.setBrush(ball_color)
        painter.setPen(QPen(QColor(255, 255, 255, 210), 2))
        painter.drawEllipse(ball_x, ball_y, self.BALL_SIZE, self.BALL_SIZE)

        painter.setPen(QColor(255, 255, 255))
        time_font = QFont()
        time_font.setPointSize(9)
        time_font.setBold(True)
        painter.setFont(time_font)

        if self.is_done:
            painter.drawText(ball_x, ball_y, self.BALL_SIZE, self.BALL_SIZE, Qt.AlignCenter, "DONE")
        else:
            hrs = self.remaining_seconds // 3600
            mins = (self.remaining_seconds % 3600) // 60
            secs = self.remaining_seconds % 60
            if hrs > 0:
                time_font.setPointSize(7)
                painter.setFont(time_font)
                time_text = f"{hrs}:{mins:02d}:{secs:02d}"
            else:
                time_text = f"{mins:02d}:{secs:02d}"
            painter.drawText(
                ball_x, ball_y, self.BALL_SIZE, self.BALL_SIZE,
                Qt.AlignCenter, time_text
            )

        if self._feedback_text:
            self._draw_feedback(painter)

    def _draw_feedback(self, painter):
        feedback_font = QFont()
        feedback_font.setPointSize(9)
        feedback_font.setBold(True)
        painter.setFont(feedback_font)

        text_rect = painter.fontMetrics().boundingRect(self._feedback_text)
        pad_x, pad_y = 8, 4
        box_w = text_rect.width() + pad_x * 2
        box_h = text_rect.height() + pad_y * 2
        box_x = (self.WIDTH - box_w) // 2
        box_y = 2  # 贴在猫的头顶附近，但要留在控件范围内，不然会被裁掉看不见

        painter.setBrush(QColor(50, 40, 35, 230))
        painter.setPen(Qt.NoPen)
        painter.drawRoundedRect(box_x, box_y, box_w, box_h, 6, 6)

        painter.setPen(QColor(255, 255, 255))
        painter.drawText(box_x, box_y, box_w, box_h, Qt.AlignCenter, self._feedback_text)
