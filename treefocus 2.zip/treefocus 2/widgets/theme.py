"""全局视觉主题：把默认的 Qt 冷灰色/黑色界面换成猫咪UI素材那种暖色调
（奶油底色、棕色边框、橙色强调色）。颜色是从 catUI.png 里实际的 HUD
卡片上精确取样的（背景 #FADCB7、边框 #403939），不是随便配的。
"""

# ---- 从素材里精确取样的颜色 ----
COLOR_APP_BG = "#FDF6EC"        # 整个程序的背景，比卡片浅一点的奶油色
COLOR_CARD_BG = "#FBEBD3"       # 卡片/面板背景（比 HUD 卡片纸稍浅，避免太重）
COLOR_CARD_BG_ALT = "#FADCB7"   # 素材原色，用在強調的卡片上
COLOR_BORDER = "#6B4A36"        # 边框深棕色
COLOR_BORDER_LIGHT = "#B98F65"  # 次要边框/分隔线
COLOR_TEXT = "#5C4033"          # 默认文字深棕色
COLOR_TEXT_MUTED = "#8A7160"    # 次要文字
COLOR_ACCENT = "#E8A662"        # 主强调色（按钮），来自暖橙色调
COLOR_ACCENT_HOVER = "#F0B87A"
COLOR_ACCENT_PRESSED = "#D4924E"
COLOR_TAB_INACTIVE = "#F0DCC0"
COLOR_WHITE_PANEL = "#FFFDF8"   # 输入框等需要浅色底的地方


def get_theme_qss() -> str:
    return f"""
    QWidget {{
        background-color: {COLOR_APP_BG};
        color: {COLOR_TEXT};
        font-family: "Microsoft YaHei", "PingFang SC", sans-serif;
    }}

    QMainWindow {{
        background-color: {COLOR_APP_BG};
    }}

    /* ---- 标签页 ---- */
    QTabWidget::pane {{
        border: 2px solid {COLOR_BORDER};
        border-radius: 8px;
        background-color: {COLOR_APP_BG};
        top: -1px;
    }}
    QTabBar::tab {{
        background-color: {COLOR_TAB_INACTIVE};
        color: {COLOR_TEXT_MUTED};
        border: 2px solid {COLOR_BORDER};
        border-bottom: none;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        padding: 8px 16px;
        margin-right: 2px;
        font-weight: bold;
    }}
    QTabBar::tab:selected {{
        background-color: {COLOR_ACCENT};
        color: white;
    }}
    QTabBar::tab:hover:!selected {{
        background-color: {COLOR_ACCENT_HOVER};
    }}

    /* ---- 按钮 ---- */
    QPushButton {{
        background-color: {COLOR_ACCENT};
        color: white;
        border: 2px solid {COLOR_BORDER};
        border-radius: 8px;
        padding: 6px 12px;
        font-weight: bold;
    }}
    QPushButton:hover {{
        background-color: {COLOR_ACCENT_HOVER};
    }}
    QPushButton:pressed {{
        background-color: {COLOR_ACCENT_PRESSED};
    }}
    QPushButton:disabled {{
        background-color: #E0D5C5;
        color: #B0A392;
        border-color: #C7B8A5;
    }}
    QPushButton:checked {{
        background-color: {COLOR_ACCENT_PRESSED};
        border-color: {COLOR_BORDER};
    }}

    /* ---- 输入控件 ---- */
    QLineEdit, QSpinBox, QTimeEdit, QComboBox {{
        background-color: {COLOR_WHITE_PANEL};
        border: 2px solid {COLOR_BORDER_LIGHT};
        border-radius: 6px;
        padding: 4px 6px;
        color: {COLOR_TEXT};
    }}
    QLineEdit:focus, QSpinBox:focus, QTimeEdit:focus, QComboBox:focus {{
        border-color: {COLOR_ACCENT};
    }}
    QComboBox::drop-down {{
        border: none;
    }}
    QComboBox QAbstractItemView {{
        background-color: {COLOR_WHITE_PANEL};
        selection-background-color: {COLOR_ACCENT};
        selection-color: white;
        border: 2px solid {COLOR_BORDER_LIGHT};
    }}

    /* ---- 列表 / 表格 ---- */
    QListWidget, QTableWidget {{
        background-color: {COLOR_WHITE_PANEL};
        border: 2px solid {COLOR_BORDER_LIGHT};
        border-radius: 6px;
        gridline-color: {COLOR_TAB_INACTIVE};
    }}
    QHeaderView::section {{
        background-color: {COLOR_TAB_INACTIVE};
        color: {COLOR_TEXT};
        border: 1px solid {COLOR_BORDER_LIGHT};
        padding: 4px;
        font-weight: bold;
    }}
    QTableWidget::item:selected, QListWidget::item:selected {{
        background-color: {COLOR_ACCENT};
        color: white;
    }}

    /* ---- 滚动区域 ---- */
    QScrollArea {{
        border: none;
        background-color: transparent;
    }}
    QScrollBar:vertical {{
        background: {COLOR_TAB_INACTIVE};
        width: 12px;
        border-radius: 6px;
    }}
    QScrollBar::handle:vertical {{
        background: {COLOR_BORDER_LIGHT};
        border-radius: 6px;
        min-height: 20px;
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0px;
    }}
    QScrollBar:horizontal {{
        background: {COLOR_TAB_INACTIVE};
        height: 12px;
        border-radius: 6px;
    }}
    QScrollBar::handle:horizontal {{
        background: {COLOR_BORDER_LIGHT};
        border-radius: 6px;
        min-width: 20px;
    }}
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
        width: 0px;
    }}

    /* ---- 弹窗 ---- */
    QDialog {{
        background-color: {COLOR_APP_BG};
    }}
    QMessageBox {{
        background-color: {COLOR_APP_BG};
    }}

    /* ---- 分组框 / 边框类 ---- */
    QFrame {{
        border-radius: 8px;
    }}

    QScrollArea > QWidget > QWidget {{
        background-color: transparent;
    }}
    """
