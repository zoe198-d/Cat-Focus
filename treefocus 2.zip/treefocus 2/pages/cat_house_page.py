import os

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton,
    QScrollArea, QFrame, QDialog, QSizePolicy, QMessageBox
)
from PySide6.QtCore import Qt, QMimeData, QPoint, QTimer
from PySide6.QtGui import QPixmap, QIcon, QPainter, QColor, QDrag, QImage, QPen

from core.cat_house_data import (
    FURNITURE_CATEGORIES, ROOM_STYLES, CAT_PRICE,
    ROOM_CANVAS_WIDTH, ROOM_CANVAS_HEIGHT,
    get_category_by_id, get_furniture_by_id, get_room_by_id, get_cat_color,
    ensure_house_fields, buy_furniture, buy_cat, select_or_buy_room,
    get_inventory_furniture, get_inventory_cats,
    place_furniture, place_cat, move_placed_furniture, move_placed_cat,
    unplace_furniture, unplace_cat, move_pet_in_room,
    feed_pet, get_pet_bar_color, HUNGER_MAX,
    CUSTOM_BACKGROUND_PRICE, get_custom_backgrounds, get_custom_background_by_id,
    is_custom_background_id, is_custom_background_owned, select_or_buy_custom_background,
    set_custom_background_crop, delete_custom_background,
)

ASSETS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets"
)
FURNITURE_DIR = os.path.join(ASSETS_DIR, "furniture")
CAT_COLORS_DIR = os.path.join(ASSETS_DIR, "cat", "colors")
ROOM_COLORS_DIR = os.path.join(ASSETS_DIR, "room", "colors")

FURNITURE_ICON_SIZE = 42  # 只用于分类入口图标（那些本来就该整齐划一）
CAT_ICON_SIZE = 40

# 摆进房间画布 / 抽屉里的物品，按原图比例放大，而不是全部挤成同一个
# 正方形——这样猫抓塔才会明显比小饭碗大，跟参考图的观感更接近。
# 画布只有 360x270，基准倍数不能太大，否则塞不下几件东西。
ROOM_ITEM_SCALE = 1.0
ROOM_ITEM_MAX_DIM = 80    # 最长边超过这个就按比例缩小（免得书架顶到天花板）
ROOM_ITEM_MIN_DIM = 16    # 最长边小于这个就按比例放大（免得小鱼干缩成一个点）

DRAWER_ITEM_MAX_DIM = 40  # 抽屉格子本身是 52x52，图标最大不超过这个
DRAWER_ITEM_MIN_DIM = 16

# 拖拽时 mime text 的前缀，用来区分拖的是家具实例还是猫
FURNITURE_MIME_PREFIX = "furniture:"
CAT_MIME_PREFIX = "cat:"


def _load_scaled_pixmap(path, size):
    if not os.path.exists(path):
        return None
    pixmap = QPixmap(path)
    if pixmap.isNull():
        return None
    return pixmap.scaled(size, size, Qt.KeepAspectRatio, Qt.FastTransformation)


def _load_natural_pixmap(path, scale=1.0, max_dim=None, min_dim=None):
    """按原图比例缩放，而不是硬塞进一个固定的正方形——保留物品之间
    真实的大小差异（猫抓塔就该比小饭碗大）。

    max_dim / min_dim 是"缩放之后"最长边的上下限，超过/不足会再按比例
    调整一次，避免特别大或特别小的素材看起来失真。
    """
    if not os.path.exists(path):
        return None
    pixmap = QPixmap(path)
    if pixmap.isNull():
        return None

    w = pixmap.width() * scale
    h = pixmap.height() * scale
    longest = max(w, h)

    if max_dim is not None and longest > max_dim:
        factor = max_dim / longest
        w *= factor
        h *= factor
    elif min_dim is not None and longest < min_dim:
        factor = min_dim / longest
        w *= factor
        h *= factor

    return pixmap.scaled(
        max(1, round(w)), max(1, round(h)), Qt.KeepAspectRatio, Qt.FastTransformation
    )


def _furniture_room_pixmap(item):
    """某件家具摆进房间/抽屉时该用的贴图（按原图比例，不是固定方块）"""
    if item is None:
        return None
    return _load_natural_pixmap(
        os.path.join(FURNITURE_DIR, item["file"]),
        scale=ROOM_ITEM_SCALE, max_dim=ROOM_ITEM_MAX_DIM, min_dim=ROOM_ITEM_MIN_DIM,
    )


def _cat_room_pixmap(color):
    return _load_natural_pixmap(
        os.path.join(CAT_COLORS_DIR, f"{color}.png"),
        scale=ROOM_ITEM_SCALE, max_dim=ROOM_ITEM_MAX_DIM, min_dim=ROOM_ITEM_MIN_DIM,
    )


def _furniture_drawer_pixmap(item):
    if item is None:
        return None
    return _load_natural_pixmap(
        os.path.join(FURNITURE_DIR, item["file"]),
        scale=ROOM_ITEM_SCALE, max_dim=DRAWER_ITEM_MAX_DIM, min_dim=DRAWER_ITEM_MIN_DIM,
    )


def _cat_drawer_pixmap(color):
    return _load_natural_pixmap(
        os.path.join(CAT_COLORS_DIR, f"{color}.png"),
        scale=ROOM_ITEM_SCALE, max_dim=DRAWER_ITEM_MAX_DIM, min_dim=DRAWER_ITEM_MIN_DIM,
    )


HEALTH_BAR_FRAME_PATH = os.path.join(ASSETS_DIR, "ui", "health_bar_frame.png")

# 素材里那条红色血条在图里的像素坐标（局部坐标系，对应 health_bar_frame.png）
_BAR_FILL_X0 = 25
_BAR_FILL_X1 = 74
_BAR_MAIN_COLOR = (155, 67, 50)
_BAR_HILIGHT_COLOR = (194, 87, 68)
_BAR_BG_COLOR = (250, 220, 183)


def _tint(rgb, factor):
    return tuple(max(0, min(255, int(c * factor))) for c in rgb)


def _build_health_bar_pixmap(hunger_fraction, cat_rgb):
    """直接复用素材表里"耳朵+红条"那张图，按饱食度百分比截断红条的
    填充范围，并把红色换成桌宠当前毛色——边框、耳朵造型这些像素画细节
    都还是原始素材，只有色块本身是程序动态算出来的。"""
    image = QImage(HEALTH_BAR_FRAME_PATH)
    if image.isNull():
        return None
    image = image.convertToFormat(QImage.Format_ARGB32)

    fill_width = _BAR_FILL_X1 - _BAR_FILL_X0
    cutoff_x = _BAR_FILL_X0 + round(fill_width * max(0.0, min(1.0, hunger_fraction)))

    main_target = cat_rgb
    hi_target = _tint(cat_rgb, 1.3)

    for y in range(image.height()):
        for x in range(_BAR_FILL_X0, _BAR_FILL_X1):
            pixel = image.pixelColor(x, y)
            rgb = (pixel.red(), pixel.green(), pixel.blue())
            if x >= cutoff_x:
                if rgb in (_BAR_MAIN_COLOR, _BAR_HILIGHT_COLOR):
                    image.setPixelColor(x, y, QColor(*_BAR_BG_COLOR, pixel.alpha()))
            elif rgb == _BAR_MAIN_COLOR:
                image.setPixelColor(x, y, QColor(*main_target, pixel.alpha()))
            elif rgb == _BAR_HILIGHT_COLOR:
                image.setPixelColor(x, y, QColor(*hi_target, pixel.alpha()))

    return QPixmap.fromImage(image)


class HealthBarWidget(QWidget):
    """桌宠的血条(饱食度) + 爱心值显示：血条图形直接用素材表里的原图，
    颜色跟着桌宠当前毛色变。"""

    DISPLAY_SCALE = 3

    def __init__(self):
        super().__init__()
        self.hunger = HUNGER_MAX
        self.love = 0
        self.color_name = "orange"

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        self.bar_label = QLabel()
        self.bar_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.bar_label)

        self.stats_label = QLabel()
        self.stats_label.setAlignment(Qt.AlignCenter)
        self.stats_label.setStyleSheet("font-size: 11px; color: #6B4A36;")
        layout.addWidget(self.stats_label)

    def set_values(self, hunger, love, color_name):
        self.hunger = hunger
        self.love = love
        self.color_name = color_name
        self._rebuild()

    def _rebuild(self):
        fraction = self.hunger / HUNGER_MAX if HUNGER_MAX else 0
        cat_rgb = get_pet_bar_color(self.color_name)
        pixmap = _build_health_bar_pixmap(fraction, cat_rgb)
        if pixmap is not None:
            scaled = pixmap.scaled(
                pixmap.width() * self.DISPLAY_SCALE, pixmap.height() * self.DISPLAY_SCALE,
                Qt.KeepAspectRatio, Qt.FastTransformation
            )
            self.bar_label.setPixmap(scaled)
        self.stats_label.setText(f"🍚 {self.hunger}/{HUNGER_MAX}　❤️ {self.love}")


class CropPreviewWidget(QWidget):
    """显示一张图片，叠加一个固定长宽比、可以拖动（不可缩放）的选框，
    用户拖它来决定图片的哪一块要用来当房间背景。"""

    PREVIEW_SIZE = 380

    def __init__(self, image, aspect_ratio):
        super().__init__()
        self.image = image
        self.aspect_ratio = aspect_ratio
        self.setFixedSize(self.PREVIEW_SIZE, self.PREVIEW_SIZE)
        self.setCursor(Qt.OpenHandCursor)

        self._recompute_image_rect()
        self._init_crop_box()

        self._dragging = False
        self._drag_start_mouse = QPoint()
        self._drag_start_box = (0.0, 0.0)

    def _recompute_image_rect(self):
        avail = self.PREVIEW_SIZE
        img_w, img_h = self.image.width(), self.image.height()
        scale = min(avail / img_w, avail / img_h)
        disp_w, disp_h = img_w * scale, img_h * scale
        self._img_rect = (
            (avail - disp_w) / 2, (avail - disp_h) / 2, disp_w, disp_h
        )

    def _init_crop_box(self):
        img_x, img_y, img_w, img_h = self._img_rect
        if img_w / img_h > self.aspect_ratio:
            box_h = img_h
            box_w = box_h * self.aspect_ratio
        else:
            box_w = img_w
            box_h = box_w / self.aspect_ratio
        box_x = img_x + (img_w - box_w) / 2
        box_y = img_y + (img_h - box_h) / 2
        self.crop_box = [box_x, box_y, box_w, box_h]

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(20, 20, 20))

        img_x, img_y, img_w, img_h = self._img_rect
        pixmap = QPixmap.fromImage(self.image).scaled(
            round(img_w), round(img_h), Qt.KeepAspectRatio, Qt.SmoothTransformation
        )
        painter.drawPixmap(round(img_x), round(img_y), pixmap)

        # 选框外的区域整体压暗，选框内的部分重新正常画一遍，形成"聚光灯"效果
        painter.fillRect(round(img_x), round(img_y), round(img_w), round(img_h), QColor(0, 0, 0, 140))

        box_x, box_y, box_w, box_h = self.crop_box
        clean_patch = pixmap.copy(
            round(box_x - img_x), round(box_y - img_y), round(box_w), round(box_h)
        )
        painter.drawPixmap(round(box_x), round(box_y), clean_patch)

        painter.setPen(QPen(QColor(255, 200, 0), 2))
        painter.setBrush(Qt.NoBrush)
        painter.drawRect(round(box_x), round(box_y), round(box_w), round(box_h))

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = True
            self._drag_start_mouse = event.position().toPoint()
            self._drag_start_box = (self.crop_box[0], self.crop_box[1])
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, event):
        if not self._dragging:
            return
        delta = event.position().toPoint() - self._drag_start_mouse
        img_x, img_y, img_w, img_h = self._img_rect
        box_w, box_h = self.crop_box[2], self.crop_box[3]

        new_x = self._drag_start_box[0] + delta.x()
        new_y = self._drag_start_box[1] + delta.y()
        new_x = max(img_x, min(new_x, img_x + img_w - box_w))
        new_y = max(img_y, min(new_y, img_y + img_h - box_h))

        self.crop_box[0] = new_x
        self.crop_box[1] = new_y
        self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = False
            self.setCursor(Qt.OpenHandCursor)

    def get_normalized_crop(self):
        img_x, img_y, img_w, img_h = self._img_rect
        box_x, box_y, box_w, box_h = self.crop_box
        return {
            "x": (box_x - img_x) / img_w,
            "y": (box_y - img_y) / img_h,
            "w": box_w / img_w,
            "h": box_h / img_h,
        }


class CropSelectionDialog(QDialog):
    """选完（或者想重新选）用哪一块图片当背景时弹出的窗口。
    不会自动裁剪/压缩——用户自己拖框决定用哪一块。"""

    def __init__(self, parent, image_path):
        super().__init__(parent)
        self.setWindowTitle("Choose which part to use")
        self.result_crop = None

        image = QImage(image_path)
        self.valid = not image.isNull()

        layout = QVBoxLayout()

        if not self.valid:
            layout.addWidget(QLabel("Couldn't load that image."))
        else:
            hint = QLabel("Drag the box to choose which part of the photo shows in the room:")
            hint.setWordWrap(True)
            hint.setAlignment(Qt.AlignCenter)
            layout.addWidget(hint)

            aspect_ratio = ROOM_CANVAS_WIDTH / ROOM_CANVAS_HEIGHT
            self.preview = CropPreviewWidget(image, aspect_ratio)
            preview_row = QHBoxLayout()
            preview_row.addStretch()
            preview_row.addWidget(self.preview)
            preview_row.addStretch()
            layout.addLayout(preview_row)

        button_row = QHBoxLayout()
        confirm_button = QPushButton("Use This Area")
        confirm_button.setEnabled(self.valid)
        confirm_button.setStyleSheet(
            "padding: 6px 12px; background-color: #4CAF50; color: white; border-radius: 6px;"
        )
        confirm_button.clicked.connect(self._on_confirm)
        button_row.addWidget(confirm_button)

        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        button_row.addWidget(cancel_button)
        layout.addLayout(button_row)

        self.setLayout(layout)

    def _on_confirm(self):
        self.result_crop = self.preview.get_normalized_crop()
        self.accept()


def _load_cropped_background_pixmap(path, crop, max_dim):
    """按存好的裁剪范围（归一化坐标）从原图里截取一块，再缩放到需要的大小。
    没有裁剪信息（比如还没解锁选过）就整张图直接缩放。"""
    if not path or not os.path.exists(path):
        return None
    image = QImage(path)
    if image.isNull():
        return None

    if crop:
        x = round(crop["x"] * image.width())
        y = round(crop["y"] * image.height())
        w = round(crop["w"] * image.width())
        h = round(crop["h"] * image.height())
        x = max(0, min(x, image.width() - 1))
        y = max(0, min(y, image.height() - 1))
        w = max(1, min(w, image.width() - x))
        h = max(1, min(h, image.height() - y))
        image = image.copy(x, y, w, h)

    pixmap = QPixmap.fromImage(image)
    return pixmap.scaled(max_dim, max_dim, Qt.KeepAspectRatio, Qt.FastTransformation)


class DraggableIcon(QLabel):
    """库存抽屉里的一个图标：按住拖出去，拖到房间画布上松手就能摆放"""


    def __init__(self, pixmap, mime_text, tooltip=""):
        super().__init__()
        if pixmap is not None:
            self.setPixmap(pixmap)
        self.setFixedSize(52, 52)
        self.setAlignment(Qt.AlignCenter)
        self.setToolTip(tooltip)
        self.setStyleSheet(
            "QLabel { background-color: white; border: 1px solid #E0D8C8; border-radius: 6px; }"
        )
        self._mime_text = mime_text

    def mousePressEvent(self, event):
        if event.button() != Qt.LeftButton:
            return
        drag = QDrag(self)
        mime = QMimeData()
        mime.setText(self._mime_text)
        drag.setMimeData(mime)
        if self.pixmap():
            drag.setPixmap(self.pixmap())
            drag.setHotSpot(QPoint(self.pixmap().width() // 2, self.pixmap().height() // 2))
        drag.exec(Qt.MoveAction)


class PlacedItemLabel(QLabel):
    """已经摆在房间画布里的一件物品：可以在画布内拖动重新摆放，
    双击收回库存。"""

    def __init__(self, pixmap, instance_key, on_moved, on_removed, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent; border: none;")
        if pixmap is not None:
            self.setPixmap(pixmap)
            self.resize(pixmap.size())
        self.instance_key = instance_key
        self.on_moved = on_moved
        self.on_removed = on_removed
        self._dragging = False
        self._press_offset = QPoint()
        self.setCursor(Qt.OpenHandCursor)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = True
            self._press_offset = event.position().toPoint()
            self.raise_()
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, event):
        if not self._dragging:
            return
        new_top_left = self.mapToParent(event.position().toPoint() - self._press_offset)
        parent_rect = self.parentWidget().rect()
        x = max(0, min(new_top_left.x(), parent_rect.width() - self.width()))
        y = max(0, min(new_top_left.y(), parent_rect.height() - self.height()))
        self.move(x, y)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.OpenHandCursor)
            self.on_moved(self.instance_key, self.x(), self.y())

    def mouseDoubleClickEvent(self, event):
        self.on_removed(self.instance_key)


class MiniPetLabel(QLabel):
    """房间画布里那只"真身"桌宠的镜像：跟桌面上的桌宠播放同一帧动画，
    可以在房间里拖着换位置，但不能双击收回（它不是买来的家具，
    是桌宠本体，一直都在）。"""

    REFRESH_MS = 150

    def __init__(self, pet, on_moved, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent; border: none;")
        self.pet = pet
        self.on_moved = on_moved
        self._dragging = False
        self._press_offset = QPoint()
        self.setCursor(Qt.OpenHandCursor)

        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self._refresh_frame)
        self.refresh_timer.start(self.REFRESH_MS)
        self._refresh_frame()

    def _refresh_frame(self):
        if self.pet is None:
            return
        frame = self.pet._current_frame()
        if frame is None:
            return
        scaled = frame.scaled(
            ROOM_ITEM_MAX_DIM, ROOM_ITEM_MAX_DIM, Qt.KeepAspectRatio, Qt.FastTransformation
        )
        # 猫的实际画幅比毛坯素材小，再收一圈，跟其他猫图标大小接近
        target = max(24, ROOM_ITEM_MAX_DIM // 2)
        scaled = scaled.scaled(target, target, Qt.KeepAspectRatio, Qt.FastTransformation)
        self.setPixmap(scaled)
        self.resize(scaled.size())

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._dragging = True
            self._press_offset = event.position().toPoint()
            self.raise_()
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, event):
        if not self._dragging:
            return
        new_top_left = self.mapToParent(event.position().toPoint() - self._press_offset)
        parent_rect = self.parentWidget().rect()
        x = max(0, min(new_top_left.x(), parent_rect.width() - self.width()))
        y = max(0, min(new_top_left.y(), parent_rect.height() - self.height()))
        self.move(x, y)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self._dragging:
            self._dragging = False
            self.setCursor(Qt.OpenHandCursor)
            self.on_moved(self.x(), self.y())


class RoomCanvas(QWidget):
    """房间画布：画出房间背景，接住从库存抽屉拖进来的物品"""

    def __init__(self, on_item_dropped):
        super().__init__()
        self.setFixedSize(ROOM_CANVAS_WIDTH, ROOM_CANVAS_HEIGHT)
        self.setAcceptDrops(True)
        self.on_item_dropped = on_item_dropped
        self._bg_pixmap = None

    def set_background(self, pixmap):
        self._bg_pixmap = pixmap
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        if self._bg_pixmap is not None:
            painter.drawPixmap(self.rect(), self._bg_pixmap)
        else:
            painter.fillRect(self.rect(), QColor("#F5EFE6"))

    def dragEnterEvent(self, event):
        if event.mimeData().hasText():
            event.acceptProposedAction()

    def dropEvent(self, event):
        text = event.mimeData().text()
        pos = event.position().toPoint()
        self.on_item_dropped(text, pos.x(), pos.y())
        event.acceptProposedAction()


class InventoryDrawer(QWidget):
    """库存抽屉：一排可以拖走的图标，横向滚动"""

    def __init__(self):
        super().__init__()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 6, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(80)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(scroll)

        content = QWidget()
        scroll.setWidget(content)
        self.row_layout = QHBoxLayout(content)
        self.row_layout.setContentsMargins(4, 4, 4, 4)
        self.row_layout.addStretch()

        self.empty_label = QLabel("Nothing here yet — go buy something from the shop below")
        self.empty_label.setStyleSheet("font-size: 11px; color: gray;")

    def set_items(self, icon_widgets):
        while self.row_layout.count():
            child = self.row_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        if not icon_widgets:
            self.row_layout.addWidget(self.empty_label)
        else:
            for icon in icon_widgets:
                self.row_layout.addWidget(icon)
        self.row_layout.addStretch()


class CategoryShopDialog(QDialog):
    """点进某个家具大类后弹出的窗口：显示这一类下所有颜色/款式，
    可以直接在这里买（买到的东西会进入库存，不会自动摆进房间）。"""

    def __init__(self, parent, category, progress, on_purchase):
        super().__init__(parent)
        self.category = category
        self.progress = progress
        self.on_purchase = on_purchase
        self._item_buttons = {}

        self.setWindowTitle(f"Choose {category['name']}")
        self.setMinimumWidth(360)

        outer = QVBoxLayout()

        title = QLabel(f"Choose a style/color for {category['name']}")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        outer.addWidget(title)

        hint = QLabel("Purchases go to your inventory — drag them out from the drawers below the room")
        hint.setStyleSheet("font-size: 11px; color: gray;")
        hint.setAlignment(Qt.AlignCenter)
        hint.setWordWrap(True)
        outer.addWidget(hint)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(420)
        outer.addWidget(scroll)

        content = QWidget()
        scroll.setWidget(content)
        grid = QGridLayout(content)
        grid.setSpacing(10)

        columns = 3
        for index, item in enumerate(category["items"]):
            row, col = divmod(index, columns)
            grid.addWidget(self._build_item_cell(item), row, col)

        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        outer.addWidget(close_button)

        self.setLayout(outer)
        self._refresh_buttons()

    def _build_item_cell(self, item):
        cell_widget = QWidget()
        cell = QVBoxLayout(cell_widget)

        icon_label = QLabel()
        pixmap = _load_scaled_pixmap(os.path.join(FURNITURE_DIR, item["file"]), 56)
        if pixmap is not None:
            icon_label.setPixmap(pixmap)
        icon_label.setAlignment(Qt.AlignCenter)
        cell.addWidget(icon_label)

        name_label = QLabel(item["name"])
        name_label.setAlignment(Qt.AlignCenter)
        name_label.setWordWrap(True)
        name_label.setStyleSheet("font-size: 11px;")
        cell.addWidget(name_label)

        price_text = "Free" if item["price"] == 0 else f"{item['price']} 🐟"
        buy_button = QPushButton(price_text)
        buy_button.setStyleSheet("padding: 4px; font-size: 11px;")
        buy_button.clicked.connect(lambda _c, item_id=item["id"]: self._on_buy(item_id))
        cell.addWidget(buy_button)
        self._item_buttons[item["id"]] = buy_button

        return cell_widget

    def _on_buy(self, item_id):
        if buy_furniture(self.progress, item_id):
            self.on_purchase()
            self._refresh_buttons()

    def _refresh_buttons(self):
        for item in self.category["items"]:
            button = self._item_buttons.get(item["id"])
            if button:
                button.setEnabled(self.progress["fish"] >= item["price"])


class RoomShopDialog(QDialog):
    """换房间风格的弹窗：解锁过的风格随时免费切换，没解锁的花小鱼干解锁。"""

    def __init__(self, parent, progress, on_change):
        super().__init__(parent)
        self.progress = progress
        self.on_change = on_change
        self._item_buttons = {}

        self.setWindowTitle("Choose Room Style")
        self.setMinimumWidth(380)

        outer = QVBoxLayout()

        title = QLabel("Choose Room Style")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        outer.addWidget(title)

        hint = QLabel("Unlocked styles can be switched anytime for free; locked ones cost fish to unlock (permanently)")
        hint.setStyleSheet("font-size: 11px; color: gray;")
        hint.setWordWrap(True)
        hint.setAlignment(Qt.AlignCenter)
        outer.addWidget(hint)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMaximumHeight(420)
        outer.addWidget(scroll)

        content = QWidget()
        scroll.setWidget(content)
        grid = QGridLayout(content)
        grid.setSpacing(10)

        columns = 3
        for index, room in enumerate(ROOM_STYLES):
            row, col = divmod(index, columns)
            grid.addWidget(self._build_room_cell(room), row, col)

        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        outer.addWidget(close_button)

        self.setLayout(outer)
        self._refresh_buttons()

    def _build_room_cell(self, room):
        cell_widget = QWidget()
        cell = QVBoxLayout(cell_widget)

        icon_label = QLabel()
        pixmap = _load_scaled_pixmap(os.path.join(ROOM_COLORS_DIR, room["file"]), 60)
        if pixmap is not None:
            icon_label.setPixmap(pixmap)
        icon_label.setAlignment(Qt.AlignCenter)
        cell.addWidget(icon_label)

        name_label = QLabel(room["name"])
        name_label.setAlignment(Qt.AlignCenter)
        name_label.setStyleSheet("font-size: 11px;")
        cell.addWidget(name_label)

        button = QPushButton()
        button.setStyleSheet("padding: 4px; font-size: 11px;")
        button.clicked.connect(lambda _c, room_id=room["id"]: self._on_select(room_id))
        cell.addWidget(button)
        self._item_buttons[room["id"]] = button

        return cell_widget

    def _on_select(self, room_id):
        if select_or_buy_room(self.progress, room_id):
            self.on_change()
            self._refresh_buttons()

    def _refresh_buttons(self):
        for room in ROOM_STYLES:
            button = self._item_buttons.get(room["id"])
            if not button:
                continue
            owned = room["id"] in self.progress["owned_rooms"]
            is_current = room["id"] == self.progress["room_style"]
            if is_current:
                button.setText("In Use")
                button.setEnabled(False)
            elif owned:
                button.setText("Switch")
                button.setEnabled(True)
            else:
                price_text = "Free" if room["price"] == 0 else f"{room['price']} 🐟"
                button.setText(f"Unlock {price_text}")
                button.setEnabled(self.progress["fish"] >= room["price"])


class CustomBackgroundDialog(QDialog):
    """自定义背景相册弹窗：显示所有拖进来存过的图片，已经解锁的可以
    免费切换，没解锁的要花 CUSTOM_BACKGROUND_PRICE 条小鱼干，
    点了会先弹一个确认框再真的扣钱。"""

    def __init__(self, parent, progress, custom_bg_dir, on_change):
        super().__init__(parent)
        self.progress = progress
        self.custom_bg_dir = custom_bg_dir
        self.on_change = on_change
        self._item_buttons = {}

        self.setWindowTitle("Custom Backgrounds")
        self.setMinimumWidth(380)

        outer = QVBoxLayout()

        title = QLabel("🖼 Custom Backgrounds")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        outer.addWidget(title)

        hint = QLabel(
            "Drag a screenshot or photo onto the cat on your desktop to add it "
            f"here for free. Using one as your room background costs "
            f"{CUSTOM_BACKGROUND_PRICE} 🐟 — once unlocked, switching back to it "
            "is always free."
        )
        hint.setStyleSheet("font-size: 11px; color: gray;")
        hint.setWordWrap(True)
        hint.setAlignment(Qt.AlignCenter)
        outer.addWidget(hint)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setMaximumHeight(420)
        outer.addWidget(self.scroll)

        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        outer.addWidget(close_button)

        self.setLayout(outer)
        self._rebuild_grid()

    def _rebuild_grid(self):
        content = QWidget()
        grid = QGridLayout(content)
        grid.setSpacing(10)

        backgrounds = get_custom_backgrounds(self.progress)
        self._item_buttons = {}

        if not backgrounds:
            empty_label = QLabel(
                "No custom backgrounds yet — drag a screenshot or photo onto "
                "the cat on your desktop to add one."
            )
            empty_label.setWordWrap(True)
            empty_label.setAlignment(Qt.AlignCenter)
            grid.addWidget(empty_label, 0, 0)
        else:
            columns = 3
            for index, bg in enumerate(backgrounds):
                row, col = divmod(index, columns)
                grid.addWidget(self._build_bg_cell(bg), row, col)

        self.scroll.setWidget(content)
        self._refresh_buttons()

    def _build_bg_cell(self, bg):
        cell_widget = QWidget()
        cell = QVBoxLayout(cell_widget)
        cell.setSpacing(2)

        # 缩略图本身就是可以点的按钮——点它触发"切换/解锁"，
        # 不再在每张图下面单独写一行"Unlock 50🐟"占地方
        thumb_button = QPushButton()
        thumb_button.setFixedSize(84, 84)
        thumb_button.setStyleSheet(
            "QPushButton { border: 2px solid #B98F65; border-radius: 6px; }"
            "QPushButton:hover { border-color: #E8A662; }"
        )
        if self.custom_bg_dir:
            pixmap = _load_scaled_pixmap(os.path.join(self.custom_bg_dir, bg["filename"]), 78)
            if pixmap is not None:
                thumb_button.setIcon(QIcon(pixmap))
                thumb_button.setIconSize(pixmap.size())
        thumb_button.clicked.connect(lambda _c, bg_id=bg["id"]: self._on_select(bg_id))
        cell.addWidget(thumb_button, alignment=Qt.AlignCenter)
        self._item_buttons[bg["id"]] = thumb_button

        status_label = QLabel()
        status_label.setAlignment(Qt.AlignCenter)
        status_label.setStyleSheet("font-size: 10px; color: #6B4A36;")
        cell.addWidget(status_label)
        self._item_buttons[f"{bg['id']}_status"] = status_label

        small_buttons = QHBoxLayout()
        small_buttons.setSpacing(4)

        edit_button = QPushButton("✂️")
        edit_button.setToolTip("Re-choose which part of this photo to use")
        edit_button.setFixedWidth(32)
        edit_button.setStyleSheet("padding: 2px; font-size: 11px;")
        edit_button.clicked.connect(lambda _c, bg_id=bg["id"]: self._on_edit_crop(bg_id))
        small_buttons.addWidget(edit_button)
        self._item_buttons[f"{bg['id']}_edit"] = edit_button

        delete_button = QPushButton("🗑")
        delete_button.setToolTip("Delete this photo")
        delete_button.setFixedWidth(32)
        delete_button.setStyleSheet("padding: 2px; font-size: 11px;")
        delete_button.clicked.connect(lambda _c, bg_id=bg["id"]: self._on_delete(bg_id))
        small_buttons.addWidget(delete_button)

        cell.addLayout(small_buttons)
        return cell_widget

    def _on_select(self, bg_id):
        already_owned = is_custom_background_owned(self.progress, bg_id)
        if not already_owned:
            answer = QMessageBox.question(
                self, "Unlock background",
                f"Spend {CUSTOM_BACKGROUND_PRICE} 🐟 fish to unlock this photo "
                "as your room background?",
                QMessageBox.Yes | QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                return

        if not select_or_buy_custom_background(self.progress, bg_id):
            return

        if not already_owned:
            # 第一次解锁：马上让用户自己选图片的哪一块要用
            self._run_crop_selection(bg_id)

        self.on_change()
        self._refresh_buttons()

    def _on_edit_crop(self, bg_id):
        self._run_crop_selection(bg_id)
        self.on_change()
        self._refresh_buttons()

    def _run_crop_selection(self, bg_id):
        bg = get_custom_background_by_id(self.progress, bg_id)
        if bg is None or not self.custom_bg_dir:
            return
        image_path = os.path.join(self.custom_bg_dir, bg["filename"])
        dialog = CropSelectionDialog(self, image_path)
        if dialog.exec() == QDialog.Accepted and dialog.result_crop:
            set_custom_background_crop(self.progress, bg_id, dialog.result_crop)

    def _on_delete(self, bg_id):
        answer = QMessageBox.question(
            self, "Delete this photo?",
            "This removes it from your album for good. If it's your current "
            "room background, the room will switch back to the default.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        filename = delete_custom_background(self.progress, bg_id)
        if filename and self.custom_bg_dir:
            try:
                os.remove(os.path.join(self.custom_bg_dir, filename))
            except OSError:
                pass

        self.on_change()
        self._rebuild_grid()

    def _refresh_buttons(self):
        for bg in get_custom_backgrounds(self.progress):
            thumb_button = self._item_buttons.get(bg["id"])
            status_label = self._item_buttons.get(f"{bg['id']}_status")
            edit_button = self._item_buttons.get(f"{bg['id']}_edit")
            if thumb_button is None:
                continue

            owned = is_custom_background_owned(self.progress, bg["id"])
            is_current = bg["id"] == self.progress.get("room_style")

            if edit_button is not None:
                edit_button.setEnabled(owned)

            if status_label is None:
                continue
            if is_current:
                status_label.setText("✓ In use")
            elif owned:
                status_label.setText("Tap to switch")
            else:
                status_label.setText(f"Tap to unlock · {CUSTOM_BACKGROUND_PRICE} 🐟")


class CatHousePage(QWidget):
    """"猫屋" 标签：完成专注攒小鱼干，按分类购买家具和猫，也可以换房间风格。
    买到的东西先进库存，从右下角的"家具/小猫/工具"抽屉里拖出来，
    松手就能摆在房间画布里，摆好之后还能拖着换位置，双击收回库存。"""

    def __init__(self, progress, save_callback, pet=None, custom_bg_dir=None):
        super().__init__()
        self.progress = progress
        self.save_callback = save_callback
        self.pet = pet  # 桌面上那只真实的桌宠实例，会在房间里显示它的镜像
        self.custom_bg_dir = custom_bg_dir  # 自定义背景相册图片存放的文件夹
        ensure_house_fields(self.progress)
        self._active_drawer = None  # 当前打开的是哪个抽屉："furniture" / "cats" / "tools" / None
        self._placed_widgets = {}  # instance_key -> PlacedItemLabel
        self._pet_label = None  # MiniPetLabel（桌宠镜像），不属于 _placed_widgets
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        outer_layout = QVBoxLayout()
        outer_layout.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer_layout.addWidget(scroll)
        self.setLayout(outer_layout)

        content = QWidget()
        scroll.setWidget(content)

        layout = QVBoxLayout(content)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(10)

        title = QLabel("🏠 My Cat House")
        title.setStyleSheet("font-size: 24px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        self.fish_label = QLabel()
        self.fish_label.setAlignment(Qt.AlignCenter)
        self.fish_label.setStyleSheet("font-size: 16px; color: #E67E22; font-weight: bold;")
        layout.addWidget(self.fish_label)

        # ---- 房间画布 + 右下角抽屉按钮 ----
        room_frame = QFrame()
        room_frame.setStyleSheet("background-color: #F5EFE6; border-radius: 10px;")
        room_outer = QVBoxLayout(room_frame)

        canvas_row = QHBoxLayout()
        canvas_row.addStretch()

        self.room_canvas = RoomCanvas(self._on_item_dropped_on_room)
        canvas_row.addWidget(self.room_canvas)
        canvas_row.addStretch()
        room_outer.addLayout(canvas_row)

        health_row = QHBoxLayout()
        health_row.addStretch()
        self.health_bar = HealthBarWidget()
        health_row.addWidget(self.health_bar)
        health_row.addStretch()
        room_outer.addLayout(health_row)

        feed_hint = QLabel("Tip: drag cat food from the \"Tools\" drawer onto the cat to feed it — "
                            "once full, feeding it more earns love points ❤️")
        feed_hint.setStyleSheet("font-size: 10px; color: gray;")
        feed_hint.setAlignment(Qt.AlignCenter)
        feed_hint.setWordWrap(True)
        room_outer.addWidget(feed_hint)

        self.status_hint_label = QLabel("")
        self.status_hint_label.setStyleSheet("font-size: 11px; color: #E67E22;")
        self.status_hint_label.setAlignment(Qt.AlignCenter)
        room_outer.addWidget(self.status_hint_label)

        drawer_button_row = QHBoxLayout()
        drawer_button_row.addStretch()
        self.furniture_drawer_button = QPushButton("🛋️ My Furniture")
        self.furniture_drawer_button.setCheckable(True)
        self.furniture_drawer_button.clicked.connect(lambda: self._toggle_drawer("furniture"))
        drawer_button_row.addWidget(self.furniture_drawer_button)

        self.cats_drawer_button = QPushButton("🐱 My Cats")
        self.cats_drawer_button.setCheckable(True)
        self.cats_drawer_button.clicked.connect(lambda: self._toggle_drawer("cats"))
        drawer_button_row.addWidget(self.cats_drawer_button)

        self.tools_drawer_button = QPushButton("🧸 Tools")
        self.tools_drawer_button.setCheckable(True)
        self.tools_drawer_button.clicked.connect(lambda: self._toggle_drawer("tools"))
        drawer_button_row.addWidget(self.tools_drawer_button)
        room_outer.addLayout(drawer_button_row)

        self.drawer = InventoryDrawer()
        self.drawer.setVisible(False)
        room_outer.addWidget(self.drawer)

        drawer_hint = QLabel("Tip: drag icons from a drawer onto the room to place them; "
                              "placed items can be dragged to reposition, or double-clicked "
                              "to send back to inventory.")
        drawer_hint.setStyleSheet("font-size: 10px; color: gray;")
        drawer_hint.setAlignment(Qt.AlignCenter)
        room_outer.addWidget(drawer_hint)

        room_style_button = QPushButton("🎨 Change Room Style")
        room_style_button.clicked.connect(self._open_room_shop)
        room_outer.addWidget(room_style_button)

        custom_bg_button = QPushButton("🖼 Custom Backgrounds")
        custom_bg_button.clicked.connect(self._open_custom_background_shop)
        room_outer.addWidget(custom_bg_button)

        custom_bg_hint = QLabel(
            "Tip: drag a screenshot or photo onto the cat on your desktop — "
            "it gets saved here for free. Using one as your room background "
            f"costs {CUSTOM_BACKGROUND_PRICE} 🐟 fish (more than the built-in styles)."
        )
        custom_bg_hint.setStyleSheet("font-size: 10px; color: gray;")
        custom_bg_hint.setAlignment(Qt.AlignCenter)
        custom_bg_hint.setWordWrap(True)
        room_outer.addWidget(custom_bg_hint)

        layout.addWidget(room_frame)

        # ---- 买猫 ----
        buy_cat_row = QHBoxLayout()
        self.cats_label = QLabel()
        buy_cat_row.addWidget(self.cats_label)
        buy_cat_row.addStretch()
        self.buy_cat_button = QPushButton(f"🐱 Buy a Cat ({CAT_PRICE} fish)")
        self.buy_cat_button.setStyleSheet(
            "padding: 6px 12px; background-color: #FF9800; color: white; border-radius: 6px;"
        )
        self.buy_cat_button.clicked.connect(self._on_buy_cat_clicked)
        buy_cat_row.addWidget(self.buy_cat_button)
        layout.addLayout(buy_cat_row)

        # ---- 家具商店：分类入口 ----
        shop_title = QLabel("🛒 Shop")
        shop_title.setStyleSheet("font-size: 16px; font-weight: bold; margin-top: 10px;")
        layout.addWidget(shop_title)

        shop_hint = QLabel("Click a category to pick a color/style — purchases go to your inventory")
        shop_hint.setStyleSheet("font-size: 11px; color: gray;")
        layout.addWidget(shop_hint)

        self.category_grid = QGridLayout()
        self.category_grid.setSpacing(10)
        layout.addLayout(self.category_grid)
        self._build_category_grid()

        layout.addStretch()

    def _build_category_grid(self):
        columns = 3
        for index, category in enumerate(FURNITURE_CATEGORIES):
            row, col = divmod(index, columns)

            button = QPushButton()
            button.setMinimumHeight(74)
            button.setStyleSheet(
                "QPushButton { text-align: center; padding: 6px; font-size: 12px; "
                "background-color: #FFFFFF; border: 1px solid #E0D8C8; border-radius: 8px; }"
                "QPushButton:hover { background-color: #FFF3E0; }"
            )
            icon_path = os.path.join(FURNITURE_DIR, category["icon"])
            pixmap = _load_scaled_pixmap(icon_path, 36)
            if pixmap is not None:
                button.setIcon(QIcon(pixmap))
                button.setIconSize(pixmap.size())
            item_count = len(category["items"])
            button.setText(f"{category['name']}\n({item_count} styles)")
            button.clicked.connect(lambda _c, cat_id=category["id"]: self._open_category(cat_id))

            self.category_grid.addWidget(button, row, col)

    # ---------- 抽屉 ----------
    def _toggle_drawer(self, drawer_name):
        for name, button in [
            ("furniture", self.furniture_drawer_button),
            ("cats", self.cats_drawer_button),
            ("tools", self.tools_drawer_button),
        ]:
            button.setChecked(name == drawer_name and self._active_drawer != drawer_name)

        if self._active_drawer == drawer_name:
            self._active_drawer = None
            self.drawer.setVisible(False)
        else:
            self._active_drawer = drawer_name
            self.drawer.setVisible(True)
            self._refresh_drawer_contents()

    def _refresh_drawer_contents(self):
        if self._active_drawer == "furniture":
            instances = get_inventory_furniture(self.progress, "furniture")
            icons = [self._make_furniture_icon(inst) for inst in instances]
        elif self._active_drawer == "tools":
            instances = get_inventory_furniture(self.progress, "tool")
            icons = [self._make_furniture_icon(inst) for inst in instances]
        elif self._active_drawer == "cats":
            cats = get_inventory_cats(self.progress)
            icons = [self._make_cat_icon(cat) for cat in cats]
        else:
            icons = []
        self.drawer.set_items(icons)

    def _make_furniture_icon(self, instance):
        item = get_furniture_by_id(instance["item_id"])
        pixmap = _furniture_drawer_pixmap(item)
        name = item["name"] if item else instance["item_id"]
        return DraggableIcon(pixmap, f"{FURNITURE_MIME_PREFIX}{instance['id']}", tooltip=name)

    def _make_cat_icon(self, cat):
        color = get_cat_color(cat["color_index"])
        pixmap = _cat_drawer_pixmap(color)
        return DraggableIcon(pixmap, f"{CAT_MIME_PREFIX}{cat['id']}", tooltip=f"{color} cat")

    # ---------- 放置到房间 ----------
    def _on_item_dropped_on_room(self, mime_text, x, y):
        # 先判断是不是把"猫粮"之类会喂食的东西，拖到了猫身上——
        # 如果是，直接喂食（消耗掉这件东西），不当成普通家具摆出去
        if mime_text.startswith(FURNITURE_MIME_PREFIX):
            instance_id = mime_text[len(FURNITURE_MIME_PREFIX):]
            inst = next(
                (i for i in self.progress["owned_furniture_instances"] if i["id"] == instance_id),
                None,
            )
            item = get_furniture_by_id(inst["item_id"]) if inst else None
            if item is not None and item.get("feeds_pet") and self._is_point_on_pet(x, y):
                self._feed_pet_and_consume(instance_id)
                return

        # 落点是拖拽热点（图标中心）的位置，换算成物品左上角坐标，
        # 并且按这件东西真实的显示大小夹在画布范围内，避免摆出去一半
        if mime_text.startswith(FURNITURE_MIME_PREFIX):
            instance_id = mime_text[len(FURNITURE_MIME_PREFIX):]
            inst = next(
                (i for i in self.progress["owned_furniture_instances"] if i["id"] == instance_id),
                None,
            )
            item = get_furniture_by_id(inst["item_id"]) if inst else None
            pixmap = _furniture_room_pixmap(item)
            w, h = (pixmap.width(), pixmap.height()) if pixmap else (FURNITURE_ICON_SIZE, FURNITURE_ICON_SIZE)
            x = max(0, min(x - w // 2, ROOM_CANVAS_WIDTH - w))
            y = max(0, min(y - h // 2, ROOM_CANVAS_HEIGHT - h))
            place_furniture(self.progress, instance_id, x, y)
        elif mime_text.startswith(CAT_MIME_PREFIX):
            cat_id = mime_text[len(CAT_MIME_PREFIX):]
            cat = next((c for c in self.progress["owned_cats"] if c["id"] == cat_id), None)
            color = get_cat_color(cat["color_index"]) if cat else "orange"
            pixmap = _cat_room_pixmap(color)
            w, h = (pixmap.width(), pixmap.height()) if pixmap else (CAT_ICON_SIZE, CAT_ICON_SIZE)
            x = max(0, min(x - w // 2, ROOM_CANVAS_WIDTH - w))
            y = max(0, min(y - h // 2, ROOM_CANVAS_HEIGHT - h))
            place_cat(self.progress, cat_id, x, y)
        else:
            return
        self._save()
        self.refresh()

    def _is_point_on_pet(self, x, y):
        if self._pet_label is None:
            return False
        rect = self._pet_label.geometry()
        return rect.contains(x, y)

    def _feed_pet_and_consume(self, instance_id):
        # 猫粮是消耗品：喂完这件东西就没了，不会进房间摆设，也不会回库存
        self.progress["owned_furniture_instances"] = [
            i for i in self.progress["owned_furniture_instances"] if i["id"] != instance_id
        ]
        result = feed_pet(self.progress)
        self._save()
        self.refresh()
        if result == "love":
            self.status_hint_label.setText("Full already! It got a little happier — +1 love point ❤️")
        else:
            self.status_hint_label.setText("The cat is a bit less hungry now 🐟")

    def _on_placed_item_moved(self, instance_key, x, y):
        kind, key = instance_key
        if kind == "furniture":
            move_placed_furniture(self.progress, key, x, y)
        else:
            move_placed_cat(self.progress, key, x, y)
        self._save()

    def _on_placed_item_removed(self, instance_key):
        kind, key = instance_key
        if kind == "furniture":
            unplace_furniture(self.progress, key)
        else:
            unplace_cat(self.progress, key)
        self._save()
        self.refresh()

    # ---------- 商店 ----------
    def _open_category(self, category_id):
        category = get_category_by_id(category_id)
        if category is None:
            return
        dialog = CategoryShopDialog(self, category, self.progress, self._on_purchase_made)
        dialog.exec()

    def _open_room_shop(self):
        dialog = RoomShopDialog(self, self.progress, self._on_purchase_made)
        dialog.exec()

    def _open_custom_background_shop(self):
        dialog = CustomBackgroundDialog(self, self.progress, self.custom_bg_dir, self._on_purchase_made)
        dialog.exec()

    def _on_purchase_made(self):
        self._save()
        self.refresh()

    def _on_buy_cat_clicked(self):
        if buy_cat(self.progress):
            self._save()
            self.refresh()

    def _save(self):
        self.save_callback(self.progress)

    # ---------- 刷新 ----------
    def refresh(self):
        ensure_house_fields(self.progress)

        self.fish_label.setText(f"🐟 Fish: {self.progress['fish']}")
        total_cats = len(self.progress["owned_cats"])
        self.cats_label.setText(f"You have {total_cats} cat(s)")
        self.buy_cat_button.setEnabled(self.progress["fish"] >= CAT_PRICE)

        current_style_id = self.progress["room_style"]
        room_pixmap = None
        if is_custom_background_id(current_style_id):
            bg = get_custom_background_by_id(self.progress, current_style_id)
            if bg is not None and self.custom_bg_dir:
                room_pixmap = _load_cropped_background_pixmap(
                    os.path.join(self.custom_bg_dir, bg["filename"]),
                    bg.get("crop"),
                    max(ROOM_CANVAS_WIDTH, ROOM_CANVAS_HEIGHT)
                )
        if room_pixmap is None:
            room = get_room_by_id(current_style_id)
            room_file = room["file"] if room else ROOM_STYLES[0]["file"]
            room_pixmap = _load_scaled_pixmap(
                os.path.join(ROOM_COLORS_DIR, room_file), max(ROOM_CANVAS_WIDTH, ROOM_CANVAS_HEIGHT)
            )
        self.room_canvas.set_background(room_pixmap)

        self._refresh_placed_items()
        if self._active_drawer is not None:
            self._refresh_drawer_contents()

        pet_color = self.pet.color if self.pet is not None else "orange"
        self.health_bar.set_values(
            self.progress.get("pet_hunger", 100),
            self.progress.get("pet_love", 0),
            pet_color,
        )

    def _refresh_placed_items(self):
        for widget in self._placed_widgets.values():
            widget.deleteLater()
        self._placed_widgets = {}

        for p in self.progress.get("placed_furniture", []):
            inst = next(
                (i for i in self.progress["owned_furniture_instances"] if i["id"] == p["instance_id"]),
                None,
            )
            if inst is None:
                continue
            item = get_furniture_by_id(inst["item_id"])
            if item is None:
                continue
            pixmap = _furniture_room_pixmap(item)
            key = ("furniture", p["instance_id"])
            label = PlacedItemLabel(
                pixmap, key, self._on_placed_item_moved, self._on_placed_item_removed,
                parent=self.room_canvas,
            )
            label.move(p["x"], p["y"])
            label.show()
            self._placed_widgets[key] = label

        for p in self.progress.get("placed_cats", []):
            cat = next((c for c in self.progress["owned_cats"] if c["id"] == p["cat_id"]), None)
            if cat is None:
                continue
            color = get_cat_color(cat["color_index"])
            pixmap = _cat_room_pixmap(color)
            key = ("cat", p["cat_id"])
            label = PlacedItemLabel(
                pixmap, key, self._on_placed_item_moved, self._on_placed_item_removed,
                parent=self.room_canvas,
            )
            label.move(p["x"], p["y"])
            label.show()
            self._placed_widgets[key] = label

        self._ensure_pet_label()

    def _ensure_pet_label(self):
        """房间里那只桌宠镜像只创建一次（它自己的动画定时器会持续跑），
        不像其他家具/猫那样每次 refresh 都重新生成。"""
        if self.pet is None:
            return
        if self._pet_label is None:
            self._pet_label = MiniPetLabel(self.pet, self._on_pet_moved, parent=self.room_canvas)
            pos = self.progress.get("pet_room_pos", {"x": 0, "y": 0})
            self._pet_label.move(pos.get("x", 0), pos.get("y", 0))
            self._pet_label.show()
        else:
            self._pet_label.raise_()

    def _on_pet_moved(self, x, y):
        move_pet_in_room(self.progress, x, y)
        self._save()

    def showEvent(self, event):
        self.refresh()
        super().showEvent(event)
