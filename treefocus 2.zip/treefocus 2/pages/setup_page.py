from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QSpinBox,
    QPushButton, QMessageBox
)
from PySide6.QtCore import Qt


class SetupPage(QWidget):
    """"计时" 标签页：输入项目名字 + 时/分/秒，并显示当前专注状态"""

    def __init__(self, on_start_callback, on_cancel_callback):
        super().__init__()
        self.on_start_callback = on_start_callback
        self.on_cancel_callback = on_cancel_callback
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(16)

        title = QLabel("⏱️ Cat Focus")
        title.setStyleSheet("font-size: 28px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        layout.addWidget(QLabel("Project name:"))
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("e.g. Write my essay / Study Python")
        layout.addWidget(self.name_input)

        layout.addWidget(QLabel("Duration:"))
        duration_row = QHBoxLayout()

        self.hour_input = QSpinBox()
        self.hour_input.setRange(0, 23)
        self.hour_input.setValue(1)
        self.hour_input.setSuffix(" hr")
        duration_row.addWidget(self.hour_input)

        self.minute_input = QSpinBox()
        self.minute_input.setRange(0, 59)
        self.minute_input.setValue(0)
        self.minute_input.setSuffix(" min")
        duration_row.addWidget(self.minute_input)

        self.second_input = QSpinBox()
        self.second_input.setRange(0, 59)
        self.second_input.setSuffix(" sec")
        duration_row.addWidget(self.second_input)

        layout.addLayout(duration_row)

        self.start_button = QPushButton("Start Focus 🐱")
        self.start_button.setStyleSheet(
            "padding: 10px; font-size: 16px; background-color: #4CAF50; "
            "color: white; border-radius: 6px;"
        )
        self.start_button.clicked.connect(self._on_start_clicked)
        layout.addWidget(self.start_button)

        self.cancel_button = QPushButton("Cancel Focus ✕")
        self.cancel_button.setStyleSheet(
            "padding: 10px; font-size: 16px; background-color: #E53935; "
            "color: white; border-radius: 6px;"
        )
        self.cancel_button.clicked.connect(self._on_cancel_clicked)
        self.cancel_button.setVisible(False)
        layout.addWidget(self.cancel_button)

        self.status_label = QLabel("No focus session running yet")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("font-size: 14px; color: gray; margin-top: 12px;")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        layout.addStretch()
        self.setLayout(layout)

    def _on_start_clicked(self):
        name = self.name_input.text().strip()
        total_seconds = (
            self.hour_input.value() * 3600
            + self.minute_input.value() * 60
            + self.second_input.value()
        )

        if not name:
            QMessageBox.warning(self, "Notice", "Please enter a project name")
            return
        if total_seconds <= 0:
            QMessageBox.warning(self, "Notice", "Please set a duration greater than 0")
            return

        self.set_status(f"Focusing on: {name}\nCheck out the cat on your desktop~")
        self.set_running(True)
        self.on_start_callback(name, total_seconds)

    def _on_cancel_clicked(self):
        self.set_running(False)
        self.set_status("This focus session was cancelled")
        if self.on_cancel_callback:
            self.on_cancel_callback()

    def set_status(self, text: str):
        self.status_label.setText(text)

    def set_running(self, is_running: bool):
        """计时进行中时，把输入框和"开始"按钮锁住，换成"取消"按钮，
        避免任何情况下打字误跑进项目名输入框里，也让用户能随时中断。"""
        self.name_input.setEnabled(not is_running)
        self.hour_input.setEnabled(not is_running)
        self.minute_input.setEnabled(not is_running)
        self.second_input.setEnabled(not is_running)
        self.start_button.setVisible(not is_running)
        self.cancel_button.setVisible(is_running)
        if is_running:
            self.name_input.clearFocus()
            self.setFocus(Qt.NoFocusReason)
