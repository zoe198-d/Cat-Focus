import uuid
from datetime import datetime, timedelta

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QSpinBox,
    QPushButton, QComboBox, QTimeEdit, QMessageBox,
    QTableWidget, QTableWidgetItem, QDialog, QFileDialog, QCheckBox,
    QTextEdit, QHeaderView
)
from PySide6.QtCore import Qt, QTime

from core.schedule_import import import_schedule_file

DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def format_duration(total_seconds: int) -> str:
    hrs = total_seconds // 3600
    mins = (total_seconds % 3600) // 60
    secs = total_seconds % 60
    parts = []
    if hrs:
        parts.append(f"{hrs}h")
    if mins:
        parts.append(f"{mins}m")
    if secs or not parts:
        parts.append(f"{secs}s")
    return "".join(parts)


class ImportScheduleDialog(QDialog):
    """"Import Schedule" dialog: pick a CSV / ICS calendar / image file,
    auto-detect entries, show a checkable preview, and only add the
    entries you keep checked when you confirm."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Import Schedule")
        self.setMinimumWidth(480)
        self.parsed_entries = []
        self.imported_entries = None  # 结果放这里，调用方读取

        layout = QVBoxLayout()

        title = QLabel("📥 Import Schedule")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        hint = QLabel(
            "Supported files:\n"
            "• .csv — columns: day, time, name, duration_minutes (day blank = every day)\n"
            "• .ics — a calendar file exported from Google/Apple/Outlook calendar\n"
            "• .png / .jpg — a photo or screenshot of a schedule (best-effort text "
            "recognition, needs the Tesseract OCR engine installed — always double-check "
            "the preview below before importing)"
        )
        hint.setStyleSheet("font-size: 11px; color: gray;")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        pick_row = QHBoxLayout()
        self.file_label = QLabel("No file selected")
        self.file_label.setStyleSheet("font-size: 12px; color: #555;")
        pick_row.addWidget(self.file_label, stretch=1)

        browse_button = QPushButton("Choose File…")
        browse_button.clicked.connect(self._on_browse)
        pick_row.addWidget(browse_button)
        layout.addLayout(pick_row)

        self.warnings_box = QTextEdit()
        self.warnings_box.setReadOnly(True)
        self.warnings_box.setMaximumHeight(80)
        self.warnings_box.setPlaceholderText("Any warnings from parsing will show up here")
        layout.addWidget(self.warnings_box)

        layout.addWidget(QLabel("Preview (uncheck anything you don't want to import):"))
        self.preview_table = QTableWidget()
        self.preview_table.setColumnCount(5)
        self.preview_table.setHorizontalHeaderLabels(["", "Day", "Time", "Task", "Duration"])
        self.preview_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.preview_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.preview_table.setMinimumHeight(220)
        layout.addWidget(self.preview_table)

        button_row = QHBoxLayout()
        self.import_button = QPushButton("Import Selected")
        self.import_button.setStyleSheet(
            "padding: 8px; font-size: 14px; background-color: #2196F3; "
            "color: white; border-radius: 6px;"
        )
        self.import_button.setEnabled(False)
        self.import_button.clicked.connect(self._on_confirm)
        button_row.addWidget(self.import_button)

        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        button_row.addWidget(cancel_button)
        layout.addLayout(button_row)

        self.setLayout(layout)

    def _on_browse(self):
        filters = "Schedule files (*.csv *.ics *.png *.jpg *.jpeg *.bmp)"
        path, _ = QFileDialog.getOpenFileName(self, "Choose a schedule file", "", filters)
        if not path:
            return
        self.file_label.setText(path.split("/")[-1])
        self._parse_and_preview(path)

    def _parse_and_preview(self, path):
        self.parsed_entries, warnings = import_schedule_file(path)
        self.warnings_box.setPlainText("\n".join(warnings) if warnings else "No issues found.")
        self._populate_preview()

    def _populate_preview(self):
        self.preview_table.setRowCount(len(self.parsed_entries))
        for row, entry in enumerate(self.parsed_entries):
            checkbox = QCheckBox()
            checkbox.setChecked(True)
            self.preview_table.setCellWidget(row, 0, checkbox)

            day = entry.get("day")
            date = entry.get("date")
            if date:
                day_text = f"{date} (once)"
            elif day is None:
                day_text = "Every day"
            else:
                day_text = DAY_NAMES[day]

            self.preview_table.setItem(row, 1, QTableWidgetItem(day_text))
            self.preview_table.setItem(row, 2, QTableWidgetItem(entry.get("time", "")))
            self.preview_table.setItem(row, 3, QTableWidgetItem(entry.get("name", "")))
            self.preview_table.setItem(
                row, 4, QTableWidgetItem(format_duration(entry.get("duration_seconds", 0)))
            )

        self.import_button.setEnabled(len(self.parsed_entries) > 0)

    def _on_confirm(self):
        selected = []
        for row, entry in enumerate(self.parsed_entries):
            checkbox = self.preview_table.cellWidget(row, 0)
            if checkbox is not None and checkbox.isChecked():
                selected.append(entry)
        self.imported_entries = selected
        self.accept()


class TimetablePage(QWidget):
    """"日程表" 标签：

    - 添加每天/每周固定时间自动触发的任务，可以直接填时长，
      也可以填"结束时间"让时长自动算出来
    - 直接点"本周总览"表格里的某一格就能编辑/删除那条安排
    """

    def __init__(self, entries, save_callback):
        super().__init__()
        self.entries = entries  # list[dict]，和 main.py 共用同一个列表对象
        self.save_callback = save_callback
        self._editing_id = None  # 当前正在编辑哪一条（None = 不在编辑，是新增模式）
        self._updating_duration = False  # 防止 结束时间<->时长 互相触发的重入
        self._build_ui()
        self._refresh_all()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(10)

        title = QLabel("📅 Schedule")
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        import_row = QHBoxLayout()
        import_row.addStretch()
        import_button = QPushButton("📥 Import Schedule")
        import_button.clicked.connect(self._open_import_dialog)
        import_row.addWidget(import_button)
        layout.addLayout(import_row)

        hint = QLabel(
            "The cat will auto-start a countdown when it's time, then go back "
            "to sleep when done.\nClick any cell in the table below to edit or "
            "delete that entry."
        )
        hint.setStyleSheet("font-size: 12px; color: gray;")
        hint.setAlignment(Qt.AlignCenter)
        hint.setWordWrap(True)
        layout.addWidget(hint)

        # ---- 添加/编辑表单 ----
        form_row1 = QHBoxLayout()
        self.day_combo = QComboBox()
        self.day_combo.addItem("Every day", None)
        for i, name in enumerate(DAY_NAMES):
            self.day_combo.addItem(name, i)
        form_row1.addWidget(self.day_combo)
        layout.addLayout(form_row1)

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Task name, e.g. Study vocabulary")
        layout.addWidget(self.name_input)

        # 开始时间 + 结束时间（两种方式之一：填结束时间会自动算出下面的时长）
        time_row = QHBoxLayout()
        time_row.addWidget(QLabel("Start:"))
        self.start_time_edit = QTimeEdit(QTime.currentTime())
        self.start_time_edit.setDisplayFormat("HH:mm")
        self.start_time_edit.timeChanged.connect(self._on_start_or_finish_changed)
        time_row.addWidget(self.start_time_edit)

        time_row.addWidget(QLabel("End (optional):"))
        self.finish_time_edit = QTimeEdit(QTime.currentTime())
        self.finish_time_edit.setDisplayFormat("HH:mm")
        self.finish_time_edit.timeChanged.connect(self._on_start_or_finish_changed)
        time_row.addWidget(self.finish_time_edit)

        self.use_finish_time_checkbox = QPushButton("Use end time to set duration")
        self.use_finish_time_checkbox.setCheckable(True)
        self.use_finish_time_checkbox.setStyleSheet(
            "QPushButton { padding: 4px 8px; font-size: 11px; }"
            "QPushButton:checked { background-color: #4CAF50; color: white; }"
        )
        self.use_finish_time_checkbox.toggled.connect(self._on_use_finish_toggled)
        time_row.addWidget(self.use_finish_time_checkbox)
        layout.addLayout(time_row)

        duration_row = QHBoxLayout()
        duration_row.addWidget(QLabel("Duration:"))
        self.hour_input = QSpinBox()
        self.hour_input.setRange(0, 23)
        self.hour_input.setValue(1)
        self.hour_input.setSuffix(" hr")
        duration_row.addWidget(self.hour_input)

        self.minute_input = QSpinBox()
        self.minute_input.setRange(0, 59)
        self.minute_input.setSuffix(" min")
        duration_row.addWidget(self.minute_input)

        self.second_input = QSpinBox()
        self.second_input.setRange(0, 59)
        self.second_input.setSuffix(" sec")
        duration_row.addWidget(self.second_input)
        layout.addLayout(duration_row)

        button_row = QHBoxLayout()
        self.save_button = QPushButton("➕ Add to Schedule")
        self.save_button.setStyleSheet(
            "padding: 8px; font-size: 14px; background-color: #2196F3; "
            "color: white; border-radius: 6px;"
        )
        self.save_button.clicked.connect(self._on_save_clicked)
        button_row.addWidget(self.save_button)

        self.delete_button = QPushButton("🗑 Delete This Entry")
        self.delete_button.setStyleSheet(
            "padding: 8px; font-size: 14px; background-color: #E53935; "
            "color: white; border-radius: 6px;"
        )
        self.delete_button.clicked.connect(self._on_delete_clicked)
        self.delete_button.setVisible(False)
        button_row.addWidget(self.delete_button)

        self.cancel_edit_button = QPushButton("Cancel Editing")
        self.cancel_edit_button.clicked.connect(self._reset_form)
        self.cancel_edit_button.setVisible(False)
        button_row.addWidget(self.cancel_edit_button)
        layout.addLayout(button_row)

        # ---- 一周总览表格（点格子编辑/删除） ----
        layout.addWidget(QLabel("This Week (click a cell to edit/delete):"))
        self.week_table = QTableWidget()
        self.week_table.setColumnCount(7)
        self.week_table.setHorizontalHeaderLabels(DAY_NAMES)
        self.week_table.verticalHeader().setVisible(False)
        self.week_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.week_table.setWordWrap(True)
        self.week_table.setMinimumHeight(220)
        self.week_table.cellClicked.connect(self._on_cell_clicked)
        layout.addWidget(self.week_table)

        self.setLayout(layout)
        self._on_use_finish_toggled(False)

    # ---------- 结束时间 <-> 时长 联动 ----------
    def _on_use_finish_toggled(self, checked):
        self.finish_time_edit.setEnabled(checked)
        self.hour_input.setEnabled(not checked)
        self.minute_input.setEnabled(not checked)
        self.second_input.setEnabled(not checked)
        if checked:
            self._recalculate_duration_from_times()

    def _on_start_or_finish_changed(self):
        if self.use_finish_time_checkbox.isChecked():
            self._recalculate_duration_from_times()

    def _recalculate_duration_from_times(self):
        start = self.start_time_edit.time()
        finish = self.finish_time_edit.time()
        start_secs = start.hour() * 3600 + start.minute() * 60 + start.second()
        finish_secs = finish.hour() * 3600 + finish.minute() * 60 + finish.second()
        diff = finish_secs - start_secs
        if diff <= 0:
            diff += 24 * 3600  # 结束时间比开始时间早，当作跨到第二天

        self._updating_duration = True
        self.hour_input.setValue(diff // 3600)
        self.minute_input.setValue((diff % 3600) // 60)
        self.second_input.setValue(diff % 60)
        self._updating_duration = False

    # ---------- 表单相关 ----------
    def _reset_form(self):
        self._editing_id = None
        self.name_input.clear()
        # 不重置 day_combo：保留用户当前选的星期几，方便连续给同一天加安排
        self.start_time_edit.setTime(QTime.currentTime())
        self.finish_time_edit.setTime(QTime.currentTime())
        self.use_finish_time_checkbox.setChecked(False)
        self.hour_input.setValue(1)
        self.minute_input.setValue(0)
        self.second_input.setValue(0)
        self.day_combo.setEnabled(True)
        self.save_button.setText("➕ Add to Schedule")
        self.delete_button.setVisible(False)
        self.cancel_edit_button.setVisible(False)

    def _find_entry_by_id(self, entry_id):
        for entry in self.entries:
            if entry.get("id") == entry_id:
                return entry
        return None

    def _on_save_clicked(self):
        name = self.name_input.text().strip()
        total_seconds = (
            self.hour_input.value() * 3600
            + self.minute_input.value() * 60
            + self.second_input.value()
        )

        if not name:
            QMessageBox.warning(self, "Notice", "Please enter a task name")
            return
        if total_seconds <= 0:
            QMessageBox.warning(self, "Notice", "Please set a duration greater than 0")
            return

        start_time_str = self.start_time_edit.time().toString("HH:mm")

        if self._editing_id is not None:
            entry = self._find_entry_by_id(self._editing_id)
            if entry is None:
                QMessageBox.warning(self, "Notice", "This entry no longer exists — it may have been deleted")
                self._reset_form()
                return
            entry["name"] = name
            entry["time"] = start_time_str
            entry["duration_seconds"] = total_seconds
            if not entry.get("date"):
                entry["day"] = self.day_combo.currentData()
        else:
            entry = {
                "id": str(uuid.uuid4()),
                "day": self.day_combo.currentData(),
                "date": None,
                "time": start_time_str,
                "name": name,
                "duration_seconds": total_seconds,
            }
            self.entries.append(entry)

        self.save_callback(self.entries)
        self._reset_form()
        self._refresh_all()

    def _on_cell_clicked(self, row, column):
        item = self.week_table.item(row, column)
        if item is None:
            return
        entry_id = item.data(Qt.UserRole)
        if not entry_id:
            return

        entry = self._find_entry_by_id(entry_id)
        if entry is None:
            return

        self._editing_id = entry_id
        self.name_input.setText(entry.get("name", ""))

        if entry.get("date"):
            self.day_combo.setCurrentIndex(0)
            self.day_combo.setEnabled(False)
        else:
            self.day_combo.setEnabled(True)
            day = entry.get("day")
            self.day_combo.setCurrentIndex(0 if day is None else day + 1)

        hh, mm = entry.get("time", "08:00").split(":")
        self.start_time_edit.setTime(QTime(int(hh), int(mm)))

        duration = entry.get("duration_seconds", 0)
        self.use_finish_time_checkbox.setChecked(False)
        self.hour_input.setValue(duration // 3600)
        self.minute_input.setValue((duration % 3600) // 60)
        self.second_input.setValue(duration % 60)

        self.save_button.setText("💾 Save Changes")
        self.delete_button.setVisible(True)
        self.cancel_edit_button.setVisible(True)

    def _on_delete_clicked(self):
        if self._editing_id is None:
            return
        self.entries[:] = [e for e in self.entries if e.get("id") != self._editing_id]
        self.save_callback(self.entries)
        self._reset_form()
        self._refresh_all()

    # ---------- 刷新显示 ----------
    def _open_import_dialog(self):
        dialog = ImportScheduleDialog(self)
        if dialog.exec() == QDialog.Accepted and dialog.imported_entries:
            self.entries.extend(dialog.imported_entries)
            self.save_callback(self.entries)
            self._refresh_all()
            QMessageBox.information(
                self, "Import complete",
                f"Added {len(dialog.imported_entries)} entries to your schedule."
            )

    def refresh(self):
        """外部（比如手动计时自动记录一条新数据后）调用，刷新显示"""
        self._refresh_all()

    def _sort_key(self, entry):
        day = entry.get("day")
        date = entry.get("date")
        if date:
            try:
                weekday = datetime.strptime(date, "%Y-%m-%d").weekday()
            except ValueError:
                weekday = 7
            return (1, weekday, entry.get("time", ""), date)
        return (0, -1 if day is None else day, entry.get("time", ""), "")

    def _refresh_all(self):
        self.entries.sort(key=self._sort_key)
        self._refresh_week_table()

    def _refresh_week_table(self):
        columns = [[] for _ in range(7)]
        for entry in self.entries:
            day = entry.get("day")
            date = entry.get("date")
            if date:
                try:
                    weekday = datetime.strptime(date, "%Y-%m-%d").weekday()
                except ValueError:
                    continue
                columns[weekday].append(entry)
            elif day is None:
                for col in columns:
                    col.append(entry)
            else:
                columns[day].append(entry)

        for col in columns:
            col.sort(key=lambda e: e.get("time", ""))

        max_rows = max((len(col) for col in columns), default=0)
        self.week_table.setRowCount(max_rows)

        for col_index, col_entries in enumerate(columns):
            for row_index in range(max_rows):
                if row_index < len(col_entries):
                    entry = col_entries[row_index]
                    duration_text = format_duration(entry.get("duration_seconds", 0))
                    label = " (log)" if entry.get("date") else ""
                    cell_text = f"{entry['time']}{label}\n{entry['name']}\n({duration_text})"
                    item = QTableWidgetItem(cell_text)
                    item.setData(Qt.UserRole, entry.get("id"))
                else:
                    item = QTableWidgetItem("")
                self.week_table.setItem(row_index, col_index, item)

        self.week_table.resizeRowsToContents()
